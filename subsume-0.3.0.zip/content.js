(function(){var e=function(e){return e.GET_TITLE_DETAILS=`GET_TITLE_DETAILS`,e.GET_WORK_DETAILS=`GET_WORK_DETAILS`,e.SEARCH_WORKS=`SEARCH_WORKS`,e.RESOLVE_PAGE_CANDIDATE=`RESOLVE_PAGE_CANDIDATE`,e.GET_BOOK_EDITIONS=`GET_BOOK_EDITIONS`,e.SET_PREFERRED_EDITION=`SET_PREFERRED_EDITION`,e.ADD_TO_ARCHIVE=`ADD_TO_ARCHIVE`,e.CHECK_ARCHIVE_STATUS=`CHECK_ARCHIVE_STATUS`,e.GET_ARCHIVE=`GET_ARCHIVE`,e.ADD_REFLECTION=`ADD_REFLECTION`,e.GET_REFLECTIONS=`GET_REFLECTIONS`,e.UPDATE_EXPERIENCE=`UPDATE_EXPERIENCE`,e.CREATE_EXPERIENCE=`CREATE_EXPERIENCE`,e.GET_EXPERIENCES=`GET_EXPERIENCES`,e.GET_RELATED_WORKS=`GET_RELATED_WORKS`,e.ASSERT_WORK_RELATION=`ASSERT_WORK_RELATION`,e.SEARCH_ADAPTATION_CANDIDATES=`SEARCH_ADAPTATION_CANDIDATES`,e.GET_SUBSUME_DISPATCH=`GET_SUBSUME_DISPATCH`,e.REGENERATE_SUBSUME_DISPATCH=`REGENERATE_SUBSUME_DISPATCH`,e.GET_LLM_PROVIDER_CAPABILITIES=`GET_LLM_PROVIDER_CAPABILITIES`,e.SUBMIT_RECOMMENDATION_FEEDBACK=`SUBMIT_RECOMMENDATION_FEEDBACK`,e.ADD_TO_LIST=`ADD_TO_LIST`,e.UPDATE_STATUS=`UPDATE_STATUS`,e.SET_USER_RATING=`SET_USER_RATING`,e.SET_USER_TAGS=`SET_USER_TAGS`,e.SET_USER_NOTES=`SET_USER_NOTES`,e.REMOVE_FROM_LIBRARY=`REMOVE_FROM_LIBRARY`,e.GET_LIBRARY=`GET_LIBRARY`,e.GET_LIBRARY_PAGE=`GET_LIBRARY_PAGE`,e.CHECK_LIBRARY_STATUS=`CHECK_LIBRARY_STATUS`,e.EXPORT_LIBRARY=`EXPORT_LIBRARY`,e.IMPORT_LIBRARY=`IMPORT_LIBRARY`,e.IMPORT_GOODREADS_CSV=`IMPORT_GOODREADS_CSV`,e.CONNECT_GOOGLE_DRIVE=`CONNECT_GOOGLE_DRIVE`,e.BACKUP_TO_DRIVE=`BACKUP_TO_DRIVE`,e.RESTORE_FROM_DRIVE=`RESTORE_FROM_DRIVE`,e.RESTORE_DEMO_LIBRARY=`RESTORE_DEMO_LIBRARY`,e.CLEAR_NOTIFICATION_BADGE=`CLEAR_NOTIFICATION_BADGE`,e.GET_MEDIA_ITEMS=`GET_MEDIA_ITEMS`,e.SEARCH_TITLES=`SEARCH_TITLES`,e.DISCOVERY_SEARCH=`DISCOVERY_SEARCH`,e.GET_RECOMMENDATIONS=`GET_RECOMMENDATIONS`,e.GET_LATEST_RELEASES=`GET_LATEST_RELEASES`,e.GET_PREFERENCES=`GET_PREFERENCES`,e.GET_FULL_PREFERENCES=`GET_FULL_PREFERENCES`,e.SET_PREFERENCES=`SET_PREFERENCES`,e.SEARCH_PERSON=`SEARCH_PERSON`,e.FOLLOW_PERSON=`FOLLOW_PERSON`,e.UNFOLLOW_PERSON=`UNFOLLOW_PERSON`,e.GET_FILMOGRAPHY=`GET_FILMOGRAPHY`,e.SYNC_FILMOGRAPHY=`SYNC_FILMOGRAPHY`,e.GET_ALL_PEOPLE=`GET_ALL_PEOPLE`,e.RESOLVE_POSTER=`RESOLVE_POSTER`,e.GET_POSTER_PREFS=`GET_POSTER_PREFS`,e.GET_CONTENT_PREFS=`GET_CONTENT_PREFS`,e.OPEN_DETAIL=`OPEN_DETAIL`,e.OPEN_CAPTURE_CANVAS=`OPEN_CAPTURE_CANVAS`,e.BUILD_WATCH_PROFILE=`BUILD_WATCH_PROFILE`,e.BUILD_TASTE_PROFILE=`BUILD_TASTE_PROFILE`,e.GET_PERSONALIZED_RECS=`GET_PERSONALIZED_RECS`,e.GET_CURATOR_PROMPT_PREVIEW=`GET_CURATOR_PROMPT_PREVIEW`,e.GET_WEEKLY_DIGEST=`GET_WEEKLY_DIGEST`,e.REGENERATE_WEEKLY_DIGEST=`REGENERATE_WEEKLY_DIGEST`,e.GET_DISCOVERY_FEED=`GET_DISCOVERY_FEED`,e.CREATE_WATCH_ALERT=`CREATE_WATCH_ALERT`,e.GET_WATCH_ALERTS=`GET_WATCH_ALERTS`,e.DELETE_WATCH_ALERT=`DELETE_WATCH_ALERT`,e.UPDATE_WATCH_ALERT=`UPDATE_WATCH_ALERT`,e.GET_FREE_DATA_SOURCE_STATUS=`GET_FREE_DATA_SOURCE_STATUS`,e}({}),t=`subsumeDiagnosticLog`;function n(){return`${Date.now()}-${Math.random().toString(36).slice(2,9)}`}async function r(){let e=(await chrome.storage.local.get(t))[t];return Array.isArray(e)?e:[]}async function i(e){await chrome.storage.local.set({[t]:e.slice(-500)})}var a=Promise.resolve();function o(e){if(!e||typeof e!=`string`)return``;let t=e.trim(),n=t.indexOf(`@`);if(n<=0)return`[REDACTED_EMAIL]`;let r=t.slice(0,n),i=t.slice(n+1);return r.includes(`*`)?t:r.length<=2?`${r[0]}***@${i}`:`${r[0]}***${r[r.length-1]}@${i}`}async function s(e,t,o,s){let c=l(o),u=s?l(s):void 0,d={id:n(),at:new Date().toISOString(),level:e,source:t,message:c,...u?{detail:u}:{}};return a=a.then(async()=>{try{let e=await r();e.push(d),await i(e)}catch{console.warn(`[Subsume diagnostic]`,e,t,c,u)}}).catch(()=>{}),a}function c(e,t,n,r){s(e,t,n,r)}function l(e){return!e||typeof e!=`string`?e:e.replace(/enc:v1:[A-Za-z0-9+/=]+:[A-Za-z0-9+/=]+/g,`[REDACTED_ENCRYPTED_KEY]`).replace(/enc:v1:[^\s"',;`]+/g,`[REDACTED_ENCRYPTED_KEY]`).replace(/Bearer\s+[A-Za-z0-9._~+/-]+/gi,`Bearer [REDACTED]`).replace(/eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]+/g,`[REDACTED_JWT]`).replace(/sk-(?:proj-|ant-)?[A-Za-z0-9_-]{15,}/g,`[REDACTED_API_KEY]`).replace(/\bAIza[0-9A-Za-z_-]{35}\b/g,`[REDACTED_API_KEY]`).replace(/([?&](?:apikey|api_key|key|token|secret|access_token|refresh_token|id_token|auth|code|state|client_secret|password|email|user|username|session|signature|sig)=)[^&\s"'`]+/gi,`$1[REDACTED]`).replace(/("(?:tmdbApiKey|omdbApiKey|llmApiKey|llmSecondaryApiKey|googleBooksApiKey)"\s*:\s*")[^"]*(")/gi,`$1[REDACTED]$2`).replace(/((?:api[_-]?key|client[_-]?secret|access[_-]?token|secret|password)["']?\s*[:=]\s*["']?)[^"'\s,;&`]+/gi,`$1[REDACTED]`).replace(/(?<![*A-Za-z0-9._%+-])[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b/g,e=>o(e))}function u(e,t,n=3e4){return new Promise((r,i)=>{let a=setTimeout(()=>{let t=`Message ${e} timed out after ${n}ms`;c(`error`,`ui.sendMessage`,t,`type=${e}`),i(Error(t))},n),o={type:e,payload:t};chrome.runtime.sendMessage(o,t=>{if(clearTimeout(a),chrome.runtime.lastError){let t=chrome.runtime.lastError.message??`Unknown chrome.runtime error`;c(`error`,`ui.sendMessage`,t,`type=${e}`),i(Error(t));return}if(!t){let t=`Message ${e} received no response`;c(`error`,`ui.sendMessage`,t),i(Error(t));return}if(!t.success){let n=t.error??`Message ${e} failed`;c(`error`,`ui.sendMessage`,n,`type=${e}`),i(Error(n));return}r(t)})})}var d=[`[class*="grid"]`,`[class*="list"]`,`[class*="row"]`,`[data-testid*="card"]`],f=[{pattern:/netflix\.com\/browse/i,hint:`high`},{pattern:/letterboxd\.com/i,hint:`medium`},{pattern:/imdb\.com\/chart/i,hint:`high`},{pattern:/primevideo\.com/i,hint:`medium`}],p=60,m=4,h=.55,g=.78;function _(e){let t=e.getBoundingClientRect();return{width:t.width||e.width||parseInt(e.getAttribute(`width`)||`0`,10)||0,height:t.height||e.height||parseInt(e.getAttribute(`height`)||`0`,10)||0}}function v(e){if(!e.src||e.src.startsWith(`data:`)||e.src.startsWith(`blob:`))return!1;let{width:t,height:n}=_(e);if(t<p||n<=0)return!1;let r=t/n;return r>=h&&r<=g}function y(e){let t=0;for(let n of e.querySelectorAll(`img`))v(n)&&t++;return t}function b(){let e=typeof window<`u`?window.location.href:``;for(let{pattern:t,hint:n}of f)if(t.test(e))return n;return null}function x(e,t){return e<m?null:t===`high`&&e>=m||e>=6?`high`:e>=m&&(t===`medium`||t===`high`)||e>=m?`medium`:null}function ee(e){let t=new Set,n=[];for(let r of d)for(let i of e.querySelectorAll(r))t.has(i)||(t.add(i),n.push(i));return n}function S(e){let t=new Set,n=Array.from(e.querySelectorAll(`img`)).filter(v);for(let r of n){let n=r.parentElement,i=0;for(;n&&n!==e&&i<12;)y(n)>=m&&t.add(n),n=n.parentElement,i++}return Array.from(t)}function te(e){return e.filter(t=>!e.some(e=>e.element!==t.element&&t.element.contains(e.element)&&e.posterCount>=t.posterCount*.75))}function C(e){let t=b(),n=new Set([...ee(e),...S(e)]),r=[];for(let e of n){let n=y(e),i=x(n,t);i&&r.push({element:e,confidence:i,posterCount:n})}return te(r).sort((e,t)=>e.confidence===t.confidence?t.posterCount-e.posterCount:e.confidence===`high`?-1:1)}var w=`data-subsume-id`,ne=[{re:/^(.{3,60})\s*\((\d{4})\)$/,titleIdx:1,yearIdx:2},{re:/^(.{3,60})\s*[-–—]\s*(\d{4})$/,titleIdx:1,yearIdx:2},{re:/^(.{3,60})\s*:\s*(\d{4})$/,titleIdx:1,yearIdx:2},{re:/^(.{3,60})\s*\((\d{4})\)\s*[—–-]\s*.+$/,titleIdx:1,yearIdx:2},{re:/^(.{3,60})\s*\([^)]*(?:TV Series|TV Mini Series|TV Movie)\s*(\d{4}).*\)$/i,titleIdx:1,yearIdx:2},{re:/^(.{3,60})\s*\((\d{4})\s+(?:TV series|TV show|Movie|Film).*\)$/i,titleIdx:1,yearIdx:2}],re=[`netflix`,`prime video`,`amazon prime`,`disney+`,`hulu`,`hbo`,`apple tv`,`hotstar`,`paramount+`,`peacock`],ie=[`movie`,`film`,`series`,`tv show`,`television`,`season`,`episode`,`imdb`,`rotten tomatoes`],ae=new Set([`SCRIPT`,`STYLE`,`NOSCRIPT`,`IFRAME`,`SVG`,`NAV`,`FOOTER`,`HEADER`,`ASIDE`,`INPUT`,`TEXTAREA`,`SELECT`,`BUTTON`,`CODE`,`PRE`]),oe=`nav, footer, header, aside, [role="navigation"], [role="banner"], .nav, .footer, .header, .sidebar, #nav, #footer, #header`;function se(){return`sub-${crypto.randomUUID()}`}function ce(e){let t=e.getBoundingClientRect();return t.width>0&&t.height>0}function le(e){return e.closest(oe)!==null}function ue(e){for(let t of ne){let n=e.match(t.re);if(n&&n[t.titleIdx].length>=3)return{title:n[t.titleIdx].trim(),yearGuess:parseInt(n[t.yearIdx],10)}}return null}function de(e){let t=[],n=e.querySelectorAll(`img[alt], img[title]`);for(let e of n){if(e.hasAttribute(w)||!ce(e)||le(e))continue;let n=ue((e.alt||e.title||``).trim());if(n){let r=se();e.setAttribute(w,r),t.push({element:e,id:r,title:n.title,yearGuess:n.yearGuess})}}return t}function fe(e){let t=[],n=e.querySelectorAll(`a`);for(let e of n){if(e.hasAttribute(w)||!ce(e)||le(e))continue;let n=(e.textContent||``).trim();if(n.length<3||n.length>80)continue;let r=e.href.toLowerCase(),i=re.some(e=>r.includes(e)),a=/imdb\.com\/title\//i.test(r);if(i||a){let r=ue(n),i=se();e.setAttribute(w,i),t.push({element:e,id:i,title:r?r.title:n,yearGuess:r?r.yearGuess:void 0});continue}let o=(e.parentElement?.textContent||``).toLowerCase();if(ie.some(e=>o.includes(e))){let r=ue(n);if(r){let n=se();e.setAttribute(w,n),t.push({element:e,id:n,title:r.title,yearGuess:r.yearGuess})}}}return t}function pe(e){let t=[],n=e.querySelectorAll(`h1, h2, h3, h4`);for(let e of n){if(e.hasAttribute(w)||!ce(e)||le(e))continue;let n=ue((e.textContent||``).trim());if(n){let r=(e.parentElement?.textContent||``).toLowerCase();if(ie.some(e=>r.includes(e))){let r=se();e.setAttribute(w,r),t.push({element:e,id:r,title:n.title,yearGuess:n.yearGuess})}}}return t}function me(e=document.body){let t=[];return t.push(...de(e)),t.push(...fe(e)),t.push(...pe(e)),t}var T=null,E=[],D=null;function he(e){let t=new Set(e);return e.filter(e=>{let n=e.parentElement;for(;n;){if(t.has(n))return!1;n=n.parentElement}return!0})}function ge(e){if(E.length===0)return;let t=E.filter(e=>document.body.contains(e));if(t=he(t),E=[],D=null,t.length===0)return;let n=[];for(let e of t)n.push(...me(e));n.length>0&&e(n)}var _e=10,ve=new Map,ye=new Set;function be(){return window.location.origin}function xe(){let e=be();return(ve.get(e)??0)>=_e?(ye.has(e)||(ye.add(e),console.warn(`[Subsume] Poster resolve budget exceeded for origin ${e} (max ${_e} per session). Skipping further resolves.`)),!1):!0}function Se(){let e=be();ve.set(e,(ve.get(e)??0)+1)}var Ce=`image.tmdb.org/t/p/`,we=[`image.tmdb.org`,`m.media-amazon.com/images`,`static.tvmaze.com/uploads`,`artworks.thetvdb.com`];function Te(e,t){if(!e.includes(Ce))return null;let n=e.split(`/`),r=n[n.length-1];if(!r)return null;let i=r.split(`.`)[0];if(!i||isNaN(parseInt(i,10)))return null;let a=`movie`;if(t){let e=t.closest(`a`);if(e){let t=e.href.toLowerCase();t.includes(`/movie/`)?a=`movie`:t.includes(`/tv/`)&&(a=`tv`)}}return{tmdbId:i,mediaType:a}}function Ee(e,t=!1){if(!e.src||e.src.startsWith(`data:`)||e.src.startsWith(`blob:`)||ae.has(e.tagName)||le(e)||e.hasAttribute(`data-subsume-poster-scanned`))return!1;if(t&&v(e)||we.some(t=>e.src.includes(t)))return!0;let n=(e.alt||``).trim(),r=n.split(/\s+/).filter(Boolean);if(r.length>=3&&/^.+\(\d{4}\)$/.test(n))return!0;if(r.length>=2){let t=e.parentElement,r=0;for(;t&&r<2;){if(t.textContent&&t.textContent.includes(n))return!0;t=t.parentElement,r++}}let i=e.getBoundingClientRect(),a=i.width||e.width,o=i.height||e.height;return a>=80&&o>=100&&n.length>=4}async function De(t,n,r=document.body,i={}){let a=i.catalogMode??!1,o=Array.from(r.querySelectorAll(`img`));r instanceof HTMLImageElement&&o.unshift(r);let s=o.filter(e=>Ee(e,a));if(s.length!==0)for(let r=0;r<s.length;r+=5){let i=s.slice(r,r+5);await Promise.all(i.map(async r=>{r.setAttribute(`data-subsume-poster-scanned`,`pending`);let i=r.src.includes(Ce),o=(r.alt||``).trim(),s=/^.+\(\d{4}\)$/.test(o),c=null;if(i?c=`tmdb-cdn`:a&&o?c=`alt-text`:a?c=`ancestor-text`:t===`medium`&&s?c=`alt-text`:t===`high`&&(c=o?`alt-text`:`ancestor-text`),!c){r.setAttribute(`data-subsume-poster-scanned`,`skip`);return}if(!xe()){r.setAttribute(`data-subsume-poster-scanned`,`skip`);return}try{let t=null;if(c===`tmdb-cdn`){let n=Te(r.src,r);if(!n){r.setAttribute(`data-subsume-poster-scanned`,`skip`);return}Se(),t=await u(e.RESOLVE_POSTER,{strategy:`tmdb-cdn`,tmdbId:n.tmdbId,mediaType:n.mediaType})}else if(c===`alt-text`)Se(),t=await u(e.RESOLVE_POSTER,{strategy:`alt-text`,query:o});else if(c===`ancestor-text`){let n=r.parentElement,i=0,a=``;for(;n&&i<2;){let e=(n.textContent||``).trim();e&&(!a||e.length<a.length)&&(a=e),n=n.parentElement,i++}let o=a.slice(0,60).trim(),s=o.split(/\s+/).filter(e=>e.length>1).length;if(!o||s<2){r.setAttribute(`data-subsume-poster-scanned`,`skip`);return}Se(),t=await u(e.RESOLVE_POSTER,{strategy:`ancestor-text`,query:o})}t&&t.success&&t.data&&t.data.match?(r.setAttribute(`data-subsume-poster-scanned`,`matched`),r.setAttribute(`data-subsume-poster-id`,t.data.match.tmdbId),n(r,t.data.match)):r.setAttribute(`data-subsume-poster-scanned`,`skip`)}catch(e){console.error(`[Subsume] Failed to resolve poster image:`,e),r.setAttribute(`data-subsume-poster-scanned`,`skip`)}})),r+5<s.length&&await new Promise(e=>setTimeout(e,50))}}var Oe=null,ke=`medium`,Ae=!1,O=null;function je(e,t,n=!1){ke=e,Oe=t,Ae=n}function Me(e){T||(T=new MutationObserver(t=>{let n=!1;for(let e of t)for(let t of e.addedNodes)t instanceof Element&&!ae.has(t.tagName)&&(E.push(t),n=!0);n&&(D&&clearTimeout(D),D=setTimeout(()=>{ge(e)},150));let r=[];for(let e of t)for(let t of e.addedNodes)(t.nodeName===`IMG`&&t instanceof HTMLImageElement||t instanceof Element&&t.querySelector(`img`))&&r.push(t);r.length>0&&Oe&&(O&&clearTimeout(O),O=setTimeout(()=>{Promise.all(r.map(e=>De(ke,Oe,e,{catalogMode:Ae}).catch(e=>{console.error(`[Subsume] Debounced scanImages failed:`,e)})))},500))}),T.observe(document.body,{childList:!0,subtree:!0}))}function Ne(){T&&=(T.disconnect(),null),D&&=(clearTimeout(D),null),O&&=(clearTimeout(O),null),E=[]}function k(e){return e.replace(/[-\s]/g,``).toUpperCase()}function A(e){let t=k(e);if(!/^\d{9}[\dX]$/.test(t))return!1;let n=0;for(let e=0;e<9;e++)n+=(10-e)*Number(t[e]);let r=t[9]===`X`?10:Number(t[9]);return n+=r,n%11==0}function j(e){let t=k(e);if(!/^\d{13}$/.test(t)||!t.startsWith(`978`)&&!t.startsWith(`979`))return!1;let n=0;for(let e=0;e<12;e++){let r=Number(t[e]);n+=e%2==0?r:r*3}return(10-n%10)%10===Number(t[12])}function Pe(e){if(!A(e))return null;let t=`978${k(e).slice(0,9)}`,n=0;for(let e=0;e<12;e++){let r=Number(t[e]);n+=e%2==0?r:r*3}return`${t}${(10-n%10)%10}`}function M(e){let t=k(e);return t.length===13&&j(t)?t:t.length===10?Pe(t):null}function Fe(e){let t=new Set,n=/\b(?:97[89][-\s]?)?(?:\d[-\s]?){9}\d\b/g,r=/\b(?:ISBN(?:-1[03])?:?\s*)?(\d{9}[\dXx]|\d{1,5}[-\s]\d{1,7}[-\s]\d{1,7}[-\s][\dXx])\b/gi;for(let r of e.matchAll(n)){let e=k(r[0]);if(e.length===13&&j(e)&&t.add(e),e.length===10&&A(e)){let n=Pe(e);n&&t.add(n),t.add(e)}}for(let n of e.matchAll(r)){let e=k(n[1]??n[0]);if(A(e)){t.add(e);let n=Pe(e);n&&t.add(n)}j(e)&&t.add(e)}return[...t]}function N(e){return e==null?[]:Array.isArray(e)?e:[e]}function Ie(e){let t=e[`@type`];return N(t).map(e=>String(e).replace(/^https?:\/\/schema\.org\//i,``)).map(e=>e.toLowerCase())}function Le(e){return e.some(e=>e===`book`||e===`audiobook`||e===`bookseries`)}function Re(e){let t=[];for(let n of N(e))if(typeof n==`string`){let e=n.trim();e&&t.push(e)}else if(n&&typeof n==`object`){let e=n,r=String(e.name??e[`@name`]??``).trim();r&&t.push(r)}return t}function ze(e){if(e){if(typeof e==`string`)return e||void 0;if(Array.isArray(e)){for(let t of e){let e=ze(t);if(e)return e}return}if(typeof e==`object`){let t=e,n=t.url??t.contentUrl??t[`@id`];if(typeof n==`string`&&n)return n}}}function Be(e){if(typeof e!=`string`)return;let t=e.match(/^(\d{4})/);if(!t)return;let n=Number(t[1]);return n>=1e3&&n<=2100?n:void 0}function Ve(e){let t=[],n=[],r=new Set,i=new Set,a=[...N(e.isbn),...N(e.isbn13),...N(e.isbn10),...N(e.identifier?.value)];for(let t of N(e.identifier))if(typeof t==`string`)a.push(t);else if(t&&typeof t==`object`){let e=t;e.value!=null&&a.push(e.value),e[`@value`]!=null&&a.push(e[`@value`])}for(let e of a){if(e==null)continue;let a=k(String(e));if(a.length===10&&A(a)&&!r.has(a)){r.add(a),t.push(a);let e=M(a);e&&!i.has(e)&&(i.add(e),n.push(e))}else a.length===13&&j(a)&&!i.has(a)&&(i.add(a),n.push(a))}return{isbn10:t,isbn13:n}}function He(e){let t=e.trim();if(!t)return[];try{let e=JSON.parse(t);if(Array.isArray(e))return e;if(e&&typeof e==`object`){let t=e;return Array.isArray(t[`@graph`])?[t,...t[`@graph`]]:[t]}return[]}catch{try{let e=JSON.parse(`[${t.replace(/}\s*{/g,`},{`)}]`);return Array.isArray(e)?e:[]}catch{return[]}}}function P(e,t){if(!e)return;if(Array.isArray(e)){for(let n of e)P(n,t);return}if(typeof e!=`object`)return;let n=e;if(t.push(n),n.mainEntity&&P(n.mainEntity,t),n[`@graph`]&&P(n[`@graph`],t),n.itemListElement){for(let e of N(n.itemListElement))if(e&&typeof e==`object`){let n=e;P(n.item??n,t)}}}function Ue(e,t,n){return e&&t?.95:e?.9:t?.88:n?.86:.85}function We(e,t){let n=Ie(e);if(!Le(n))return null;let r=String(e.name??e.headline??``).trim();if(!r)return null;let i=Re(e.author),{isbn10:a,isbn13:o}=Ve(e),s=a.length>0||o.length>0,c=ze(e.image),l=Be(e.datePublished),u=Ue(s,i.length>0,!!c),d=[{type:`json_ld`,value:n[0]||`Book`,weight:.85}];return s&&d.push({type:`isbn`,value:o[0]||a[0],weight:.9}),{medium:`book`,title:r,authorOrCreator:i.length?i:void 0,year:l,isbn10:a.length?a:void 0,isbn13:o.length?o:void 0,imageUrl:c,sourcePageUrl:t,confidence:u,evidence:d,providerHint:void 0}}function Ge(e,t){let n=[],r=e.querySelectorAll(`script[type="application/ld+json"]`);for(let e of r){let r=He(e.textContent||``),i=[];for(let e of r)P(e,i);for(let e of i){let r=We(e,t);r&&n.push(r)}}return n}var Ke=RegExp(`\\b(?:${`book.novel.author.isbn.paperback.hardcover.hardback.softcover.audiobook.publisher.edition.volume.literature.memoir.essay.fiction.nonfiction.non-fiction.reading.reader.writer.bestseller.best-seller.chapters.page count.pages.kindle.epub.library`.split(`.`).map(e=>e.replace(/[.*+?^${}()|[\]\\]/g,`\\$&`)).join(`|`)})\\b`,`i`),qe=120;function Je(e,t,n){let r=Math.max(0,t-qe),i=Math.min(e.length,t+n+qe);return Ke.test(e.slice(r,i))}function Ye(e){let t=[],n=[],r=new Set,i=new Set;for(let a of e){let e=k(a);if(e.length===10&&A(e)&&!r.has(e)){r.add(e),t.push(e);let a=M(e);a&&!i.has(a)&&(i.add(a),n.push(a))}else e.length===13&&j(e)&&!i.has(e)&&(i.add(e),n.push(e))}return{isbn10:t,isbn13:n}}function Xe(e){let t=[];for(let n of e.querySelectorAll(`meta`)){let e=(n.getAttribute(`name`)||n.getAttribute(`property`)||``).toLowerCase(),r=n.getAttribute(`content`)||``;r&&(e.includes(`isbn`)||e.includes(`book`)||e===`description`||e===`og:description`||e===`og:title`||e===`twitter:title`||e===`keywords`)&&t.push(`${e} ${r}`)}for(let n of e.querySelectorAll(`[itemprop="isbn"], [data-isbn], [data-asin]`)){let e=n.getAttribute(`content`)||n.getAttribute(`data-isbn`)||n.getAttribute(`data-asin`)||n.textContent||``;e.trim()&&t.push(`isbn ${e}`)}return t.join(`
`)}function Ze(e,t={}){let n=t.requireContext!==!1,r=e.body?.innerText||e.body?.textContent||``,i=`${Xe(e)}\n${r}`;if(!n)return Ye(Fe(i));let a=[];for(let e of i.matchAll(/ISBN(?:-1[03])?:?\s*([0-9][0-9\- ]{8,16}[0-9Xx])/gi)){let t=k(e[1]);(A(t)||j(t))&&a.push(t)}let o=Fe(i),s=[...a];for(let e of o){let t=k(e),n=e.replace(/[-\s]/g,``),r=i.toUpperCase().indexOf(n.toUpperCase());r!==-1&&Je(i,r,n.length)&&s.push(t)}return Ye(s)}function Qe(e,t,n,r=.78){if(e.length===0&&t.length===0)return[];let i=t[0]||e[0]||``;return[{medium:`book`,title:``,isbn10:e.length?e:void 0,isbn13:t.length?t:void 0,sourcePageUrl:n,confidence:r,evidence:[{type:`isbn`,value:i,weight:.75}]}]}function $e(e,t){let n=e.toLowerCase();return t.some(e=>{let t=e.toLowerCase();return t.endsWith(`.`)?n===t.slice(0,-1)||n.startsWith(t)||n.includes(`.${t}`):n===t||n.endsWith(`.${t}`)})}function F(e,...t){for(let n of t){let t=n.toLowerCase();for(let n of e.querySelectorAll(`meta`))if((n.getAttribute(`name`)||n.getAttribute(`property`)||``).toLowerCase()===t){let e=n.getAttribute(`content`)?.trim();if(e)return e}}}function et(e){if((F(e,`og:type`,`og:type`)||``).toLowerCase().includes(`book`))return!0;let t=F(e,`books:author`,`book:author`),n=F(e,`books:isbn`,`book:isbn`);return!!(t||n)}function tt(e){return(e.querySelector(`h1`)?.textContent||``).replace(/\s+/g,` `).trim()}function nt(e,t){return Ze(e,{requireContext:t})}function rt(e){let t=[],n=[],r=new Set,i=new Set;for(let a of e){let e=k(a);if(e.length===10&&A(e)&&!r.has(e)){r.add(e),t.push(e);let a=M(e);a&&!i.has(a)&&(i.add(a),n.push(a))}else e.length===13&&j(e)&&!i.has(e)&&(i.add(e),n.push(e))}return{isbn10:t,isbn13:n}}function it(e,t,n){let r=Ge(e,t.href).map(e=>({...e,confidence:Math.max(e.confidence,.9),providerHint:e.providerHint||n,evidence:[...e.evidence,{type:`domain_adapter`,value:n,weight:.85},{type:`url_pattern`,value:t.hostname,weight:.7}]}));if(r.length)return r;let i=(F(e,`og:title`,`twitter:title`)||tt(e)||e.title||``).replace(/\s*[|\-–—].*$/,``).trim();if(!i)return[];let a=F(e,`books:author`,`book:author`,`author`,`citation_author`)||``,o=a?a.split(/,|;|\band\b/i).map(e=>e.trim()).filter(Boolean):void 0,s=F(e,`books:isbn`,`book:isbn`,`citation_isbn`),c=s?rt([s]):{isbn10:[],isbn13:[]},l=nt(e,!1),u=[...new Set([...c.isbn10,...l.isbn10])],d=[...new Set([...c.isbn13,...l.isbn13])],f=F(e,`og:image`,`twitter:image`),p=u.length>0||d.length>0,m=p?.92:o?.length?.88:.86;return[{medium:`book`,title:i,authorOrCreator:o,isbn10:u.length?u:void 0,isbn13:d.length?d:void 0,imageUrl:f,sourcePageUrl:t.href,confidence:m,evidence:[{type:`domain_adapter`,value:n,weight:.85},{type:`url_pattern`,value:t.hostname,weight:.7},...p?[{type:`isbn`,value:d[0]||u[0],weight:.85}]:[],...et(e)?[{type:`open_graph`,value:`book`,weight:.7}]:[]],providerHint:n}]}var at={id:`openlibrary`,hostPatterns:[`openlibrary.org`],detect(e,t){return/\/(works|books|isbn)\//i.test(t.pathname)?it(e,t,`openlibrary`):Ge(e,t.href).map(e=>({...e,providerHint:`openlibrary`,confidence:Math.max(e.confidence,.88),evidence:[...e.evidence,{type:`domain_adapter`,value:`openlibrary`,weight:.8}]}))}},ot={id:`google_books`,hostPatterns:[`books.google.`],detect(e,t){return it(e,t,`googlebooks`)}},st={id:`goodreads`,hostPatterns:[`goodreads.com`],detect(e,t){if(!/\/book\//i.test(t.pathname))return[];let n=it(e,t,`goodreads`);if(n.length)return n;let r=((e.querySelector(`#bookTitle, h1.Text__title1, [data-testid="bookTitle"]`)||e.querySelector(`h1`))?.textContent||``).replace(/\s+/g,` `).trim();if(!r)return[];let i=e.querySelectorAll(`.authorName, a.ContributorLink, [data-testid="name"], .ContributorLink__name`),a=Array.from(i).map(e=>(e.textContent||``).replace(/\s+/g,` `).trim()).filter(Boolean).slice(0,5),{isbn10:o,isbn13:s}=nt(e,!1),c=F(e,`og:image`)||e.querySelector(`.BookCover__image img, #coverImage`)?.src;return[{medium:`book`,title:r,authorOrCreator:a.length?a:void 0,isbn10:o.length?o:void 0,isbn13:s.length?s:void 0,imageUrl:c||void 0,sourcePageUrl:t.href,confidence:s.length||o.length?.93:.88,evidence:[{type:`domain_adapter`,value:`goodreads`,weight:.9},{type:`url_pattern`,value:`/book/`,weight:.8}],providerHint:`goodreads`}]}},ct={id:`amazon`,hostPatterns:[`amazon.`],detect(e,t){if(!/\/(dp|gp\/product)\//i.test(t.pathname))return[];let n=(e.body?.innerText||``).slice(0,8e3);if(!(et(e)||/(?:books|literature|fiction|nonfiction|kindle|paperback|hardcover)/i.test(n)||e.querySelector(`#add-to-ebooks-cart, #booksTitle, #titleSpanId, #bylineInfo`))){let t=nt(e,!0);if(!t.isbn10.length&&!t.isbn13.length)return[]}let r=F(e,`og:title`)||(e.querySelector(`#productTitle, #title, #ebooksProductTitle`)?.textContent||``).replace(/\s+/g,` `).trim()||tt(e);if(!r)return[];let i=(e.querySelector(`#bylineInfo, .author`)?.textContent||``).replace(/\s+/g,` `).trim(),a=i?i.replace(/^(by|author[s]?)\s*:?\s*/i,``).split(/,|;|\band\b|\(/i).map(e=>e.replace(/\s*\(.*$/,``).trim()).filter(e=>e&&!/^(visit|follow|see all)/i.test(e)).slice(0,5):void 0,{isbn10:o,isbn13:s}=nt(e,!1),c=F(e,`og:image`);return[{medium:`book`,title:r.replace(/\s*[|\-–—].*$/,``).trim(),authorOrCreator:a?.length?a:void 0,isbn10:o.length?o:void 0,isbn13:s.length?s:void 0,imageUrl:c,sourcePageUrl:t.href,confidence:s.length||o.length?.9:.86,evidence:[{type:`domain_adapter`,value:`amazon`,weight:.85},{type:`url_pattern`,value:`/dp/`,weight:.75}],providerHint:`amazon`}]}},lt=/\b(novel|novella|book by|written by|author|isbn|publisher|publication|first published|literary|fiction|non-fiction|nonfiction|memoir|essay collection)\b/i,ut=[at,ot,st,ct,{id:`wikipedia`,hostPatterns:[`wikipedia.org`],detect(e,t){if(!/\/wiki\//i.test(t.pathname)||/\/wiki\/(File|Category|Help|Wikipedia|Template|Special|Talk|User):/i.test(t.pathname))return[];let n=e.querySelector(`.infobox, .infobox-book, table.infobox`),r=n?.textContent||``,i=`${r}\n${(e.querySelector(`#mw-content-text p`)?.textContent||``).slice(0,600)}`;if(!(lt.test(i)||/infobox.*book|book infobox/i.test(n?.className||``)||n?.querySelector(`th`)&&/author|publisher|isbn|publication/i.test(r)))return[];let a=(e.querySelector(`#firstHeading, h1`)?.textContent||``).replace(/\s+/g,` `).trim()||decodeURIComponent(t.pathname.replace(/^\/wiki\//,``)).replace(/_/g,` `);if(!a)return[];let o;if(n)for(let e of n.querySelectorAll(`tr`)){let t=(e.querySelector(`th`)?.textContent||``).toLowerCase();if(/^author/.test(t)||t.includes(`author`)){let t=(e.querySelector(`td`)?.textContent||``).replace(/\s+/g,` `).replace(/\[.*?\]/g,``).trim();t&&(o=t.split(/,|;|\band\b/i).map(e=>e.trim()).filter(Boolean).slice(0,5));break}}let{isbn10:s,isbn13:c}=rt(Fe(r||i)),l=e.querySelector(`.infobox img`)?.src||F(e,`og:image`);return[{medium:`book`,title:a,authorOrCreator:o,isbn10:s.length?s:void 0,isbn13:c.length?c:void 0,imageUrl:l||void 0,sourcePageUrl:t.href,confidence:c.length||s.length?.9:o?.length?.86:.8,evidence:[{type:`domain_adapter`,value:`wikipedia`,weight:.8},{type:`url_pattern`,value:`wikipedia`,weight:.65}],providerHint:`wikipedia`}]}}];function dt(e,t){let n=[];for(let r of ut)if($e(t.hostname,r.hostPatterns))try{let i=r.detect(e,t);n.push(...i)}catch{}return n}var ft=/[“"«]?([A-Z0-9][^"“”»\n]{2,80}?)[”"»]?\s+by\s+([A-Z][a-zA-Z.''-]+(?:\s+[A-Z][a-zA-Z.''-]+){0,4})/g,pt=/(?:review(?:s)? of|reading|book review)\s*[:\-–—]?\s*[“"«]?([^"“”»\n]{3,80})[”"»]?/gi,mt=3,ht=120,gt=12;function _t(e){return e.replace(/\s+/g,` `).replace(/^[\s:–—-]+|[\s:–—-]+$/g,``).replace(/[“”«»"']/g,``).trim()}function vt(e){return e.replace(/\s+/g,` `).replace(/[,.;:]+$/,``).replace(/\s+\(.*\)$/,``).trim()}function yt(e){return!(e.length<mt||e.length>ht||/^https?:\/\//i.test(e)||/@/.test(e)||!/[A-Za-z]/.test(e)||/^(click here|read more|home|about|contact)$/i.test(e))}function bt(e){return!(e.length<2||e.length>60||!/^[A-Za-z]/.test(e)||/\b(the|and|with|from|that|this|which|when|where)\b/i.test(e)&&e.split(/\s+/).length>4)}function xt(e,t,n){let r=`${n.title.toLowerCase()}|${(n.authorOrCreator||[]).join(`,`).toLowerCase()}`;t.has(r)||(t.add(r),e.push(n))}function St(e,t){let n=[],r=new Set,i=/review/i.test(e.title||``)||/review/i.test(t)||!!e.querySelector(`[itemtype*="Review"], meta[property="og:type"][content*="article"]`);for(let a of e.querySelectorAll(`h1, h2, h3`)){let e=(a.textContent||``).replace(/\s+/g,` `).trim();ft.lastIndex=0;let o=ft.exec(e);if(!o)continue;let s=_t(o[1]),c=vt(o[2]);!yt(s)||!bt(c)||xt(n,r,{medium:`book`,title:s,authorOrCreator:[c],sourcePageUrl:t,confidence:i?.78:.72,evidence:[{type:`title_author_text`,value:`${s} by ${c}`,weight:.7}]})}let a=(e.body?.innerText||e.body?.textContent||``).slice(0,4e4);ft.lastIndex=0;for(let e of a.matchAll(ft)){if(n.length>=gt)break;let i=_t(e[1]),a=vt(e[2]);if(!yt(i)||!bt(a))continue;let o=/[“"«]/.test(e[0]);xt(n,r,{medium:`book`,title:i,authorOrCreator:[a],sourcePageUrl:t,confidence:o?.74:.7,evidence:[{type:`title_author_text`,value:`${i} by ${a}`,weight:o?.72:.65}]})}if(i&&n.length<gt){pt.lastIndex=0;for(let e of a.matchAll(pt)){if(n.length>=gt)break;let i=_t(e[1]);if(!yt(i))continue;let o=a.slice(Math.max(0,(e.index??0)-80),Math.min(a.length,(e.index??0)+e[0].length+160)).match(/\bby\s+([A-Z][a-zA-Z.''-]+(?:\s+[A-Z][a-zA-Z.''-]+){0,3})/),s=o?vt(o[1]):void 0;s&&bt(s)?xt(n,r,{medium:`book`,title:i,authorOrCreator:[s],sourcePageUrl:t,confidence:.76,evidence:[{type:`title_author_text`,value:`review: ${i}`,weight:.7}]}):xt(n,r,{medium:`book`,title:i,sourcePageUrl:t,confidence:.55,evidence:[{type:`title_author_text`,value:i,weight:.4}]})}}return n.slice(0,gt)}var Ct=.85;function wt(e){return e.toLowerCase().replace(/[^a-z0-9\s]/g,``).replace(/\s+/g,` `).trim()}function Tt(e){return(e||[]).map(e=>e.toLowerCase().replace(/[^a-z0-9\s]/g,``).trim()).filter(Boolean).sort().join(`|`)}function Et(e){if(e.isbn13?.length)return k(e.isbn13[0]);if(e.isbn10?.length)return M(e.isbn10[0])||k(e.isbn10[0])}function Dt(e,t){let n=[...new Set([...e.isbn10||[],...t.isbn10||[]])],r=[...new Set([...e.isbn13||[],...t.isbn13||[]])],i=[...new Set([...e.authorOrCreator||[],...t.authorOrCreator||[]])],a=[...e.evidence,...t.evidence],o=Math.min(.08,a.length*.01),s=Math.min(.98,Math.max(e.confidence,t.confidence)+o);return{medium:`book`,title:e.title&&t.title?e.title.length>=t.title.length?e.title:t.title:e.title||t.title,authorOrCreator:i.length?i:void 0,year:e.year??t.year,isbn10:n.length?n:void 0,isbn13:r.length?r:void 0,imageUrl:e.imageUrl||t.imageUrl,sourcePageUrl:e.sourcePageUrl||t.sourcePageUrl,confidence:s,evidence:a,providerHint:e.providerHint||t.providerHint}}function Ot(e){let t=new Map,n=new Map,r=[];for(let i of e){let e=Et(i);if(e){let n=t.get(e);t.set(e,n?Dt(n,i):i);continue}let a=wt(i.title||``);if(a){let e=`${a}::${Tt(i.authorOrCreator)}`,t=`${a}::`,r=n.get(e)||(i.authorOrCreator?.length?n.get(t):void 0);if(r){let e=Dt(r,i);n.delete(t),n.set(`${wt(e.title)}::${Tt(e.authorOrCreator)}`,e)}else n.set(e,i);continue}r.push(i)}let i=[...t.values()],a=[];for(let e of n.values()){let n=wt(e.title),r=i.find(e=>wt(e.title)===n&&n.length>0);if(r){let n=Dt(r,e),i=Et(n);t.set(i,n)}else a.push(e)}return[...t.values(),...a,...r]}function kt(e,t){let n=t.href,r=[];r.push(...Ge(e,n));let i=dt(e,t);r.push(...i);let a=i.length>0,{isbn10:o,isbn13:s}=Ze(e,{requireContext:!a}),c=new Set(r.flatMap(e=>[...(e.isbn13||[]).map(k),...(e.isbn10||[]).map(e=>M(e)||k(e))])),l=o.filter(e=>!c.has(k(e))&&!c.has(M(e)||``)),u=s.filter(e=>!c.has(k(e)));(l.length||u.length)&&r.push(...Qe(l,u,n,a?.88:.8)),r.push(...St(e,n));for(let t of r)if(!t.title&&(t.isbn13?.length||t.isbn10?.length)){let n=e.querySelector(`meta[property="og:title"]`)?.getAttribute(`content`),r=e.querySelector(`h1`)?.textContent?.replace(/\s+/g,` `).trim(),i=(n||r||``).trim();i&&i.length>=3&&i.length<=120&&(t.title=i.replace(/\s*[|\-–—].*$/,``).trim(),t.confidence=Math.min(.9,t.confidence+.05))}return Ot(r).filter(e=>e.confidence>=.65&&(e.title||Et(e))).sort((e,t)=>t.confidence-e.confidence)}function At(e){return e==null?[]:Array.isArray(e)?e:[e]}function jt(e){let t=e[`@type`];return At(t).map(e=>String(e).replace(/^https?:\/\/schema\.org\//i,``)).map(e=>e.toLowerCase())}function Mt(e){return e.some(e=>e===`tvseries`||e===`tvseason`||e===`tvepisode`||e===`radioseries`||e===`tvshow`)}function Nt(e){return e.some(e=>e===`movie`||e===`motionpicture`||e===`videoobject`)}function Pt(e){let t=e.name??e.headline??e.alternateName;return typeof t==`string`?t.trim():Array.isArray(t)&&typeof t[0]==`string`?t[0].trim():``}function Ft(e){if(typeof e!=`string`)return;let t=e.match(/^(\d{4})/);if(!t)return;let n=Number(t[1]);return n>=1880&&n<=2100?n:void 0}function It(e){if(e){if(typeof e==`string`)return e||void 0;if(Array.isArray(e)){for(let t of e){let e=It(t);if(e)return e}return}if(typeof e==`object`){let t=e,n=t.url??t.contentUrl??t[`@id`];if(typeof n==`string`&&n)return n}}}function Lt(e){let t=[];for(let n of At(e.genre))if(typeof n==`string`)t.push(n);else if(n&&typeof n==`object`){let e=n.name;typeof e==`string`&&t.push(e)}for(let n of At(e.keywords))typeof n==`string`&&t.push(n);return t.join(` `).toLowerCase()}function Rt(e,t){let n=Lt(e);if(/\bdocumentary\b|\bdocuseries\b|\bnon[- ]fiction film\b/.test(n)||/\bdocumentary\b/i.test(t))return!0;let r=String(e.description??``).toLowerCase();return!!/\bdocumentary film\b|\bthis documentary\b/.test(r.slice(0,400))}function zt(e,t){if(!e)return;if(Array.isArray(e)){for(let n of e)zt(n,t);return}if(typeof e!=`object`)return;let n=e;t.push(n),n[`@graph`]&&zt(n[`@graph`],t);for(let e of[`itemListElement`,`hasPart`,`workExample`])n[e]&&zt(n[e],t)}function Bt(e){try{return JSON.parse(e)}catch{try{let t=e.replace(/,\s*([\]}])/g,`$1`);return JSON.parse(t)}catch{return null}}}function Vt(e,t){let n=jt(e),r=Mt(n),i=Nt(n);if(!r&&!i)return null;let a=Pt(e);if(!a||a.length<2)return null;let o=!r&&Rt(e,a),s=Ft(e.datePublished)??Ft(e.dateCreated)??Ft(e.releaseDate),c=.88;return(e.image||e.trailer)&&(c+=.03),s&&(c+=.02),o&&(c=Math.min(.95,c+.01)),c=Math.min(.97,c),{medium:r?`tv`:`movie`,screenKind:r?`tv`:o?`documentary`:`movie`,title:a,year:s,imageUrl:It(e.image),sourcePageUrl:t,confidence:c,evidence:[{type:`json_ld`,value:n.join(`,`),weight:.9},...o?[{type:`json_ld`,value:`documentary`,weight:.85}]:[]]}}function I(e,t){let n=e.querySelectorAll(`script[type="application/ld+json"]`),r=[];for(let e of n){let t=e.textContent?.trim();t&&zt(Bt(t),r)}let i=[],a=new Set;for(let e of r){let n=Vt(e,t);if(!n)continue;let r=`${n.screenKind}::${n.title.toLowerCase()}`;a.has(r)||(a.add(r),i.push(n))}return i.sort((e,t)=>t.confidence-e.confidence)}function Ht(e,t){let n=e.toLowerCase().replace(/^www\./,``);return t.some(e=>{let t=e.toLowerCase().replace(/^www\./,``);return t.endsWith(`.`)?n===t.slice(0,-1)||n.startsWith(t)||n.includes(`.${t}`):n===t||n.endsWith(`.${t}`)})}function L(e,...t){for(let n of t){let t=n.toLowerCase();for(let n of e.querySelectorAll(`meta`))if((n.getAttribute(`name`)||n.getAttribute(`property`)||``).toLowerCase()===t){let e=n.getAttribute(`content`)?.trim();if(e)return e}}}function Ut(e){return(e.querySelector(`h1`)?.textContent||``).replace(/\s+/g,` `).trim()}function Wt(e){let t=e.match(/\b(19|20)\d{2}\b/);if(t)return Number(t[0])}function Gt(e){return e.replace(/\s*[|\-–—•].*$/,``).replace(/\s*\(\d{4}\)\s*$/,``).replace(/\s+/g,` `).trim()}function R(e,t,n){return{...e,confidence:Math.min(.98,Math.max(e.confidence,.9)),providerHint:e.providerHint||t,evidence:[...e.evidence,{type:`domain_adapter`,value:t,weight:.9},{type:`url_pattern`,value:n,weight:.8}]}}function z(e,t,n,r,i){let a=L(e,`og:title`,`twitter:title`)||``,o=Ut(e),s=e.title||``,c=a||o||s;if(!c||c.length<2)return null;let l=Gt(c);if(!l||l.length<2||l.length>120)return null;let u=`${c} ${s} ${L(e,`og:description`)||``}`.toLowerCase(),d=i||`movie`;i||(/\btv series\b|\btv mini\b|\btelevision series\b|\bseason \d|\bepisodes?\b/.test(u)?d=`tv`:/\bdocumentary\b|\bdocuseries\b/.test(u)&&(d=`documentary`));let f=Wt(c)??Wt(s),p=L(e,`og:image`,`twitter:image`);return{medium:d===`tv`?`tv`:`movie`,screenKind:d,title:l,year:f,imageUrl:p,sourcePageUrl:t.href,confidence:.9,evidence:[{type:`domain_adapter`,value:n,weight:.9},{type:`url_pattern`,value:r,weight:.85},{type:`open_graph`,value:a?`og:title`:`h1`,weight:.7}],providerHint:n}}var Kt=[{id:`imdb`,hostPatterns:[`imdb.com`],detect(e,t){if(!/\/title\/tt\d+/i.test(t.pathname))return[];let n=(e.querySelector(`[data-testid="hero-subnav-bar"]`)?.textContent||e.querySelector(`.ipc-inline-list`)?.textContent||``).toLowerCase(),r;/tv (mini )?series|tv episode/.test(n)?r=`tv`:/documentary/.test(n)&&(r=`documentary`);let i=I(e,t.href).map(e=>R(r&&r!==e.screenKind?{...e,screenKind:r,medium:r===`tv`?`tv`:`movie`,confidence:Math.min(.97,e.confidence+.02),evidence:[...e.evidence,{type:`domain_adapter`,value:`imdb:${r}`,weight:.92}]}:e,`imdb`,`/title/tt`));if(i.length)return i;let a=z(e,t,`imdb`,`/title/tt`,r);return a?[a]:[]}},{id:`letterboxd`,hostPatterns:[`letterboxd.com`],detect(e,t){if(!/\/film\//i.test(t.pathname))return[];let n=I(e,t.href).map(e=>R(e,`letterboxd`,`/film/`));if(n.length)return n;let r=z(e,t,`letterboxd`,`/film/`);return r?[r]:[]}},{id:`rottentomatoes`,hostPatterns:[`rottentomatoes.com`],detect(e,t){let n=/\/tv\//i.test(t.pathname),r=/\/m\//i.test(t.pathname);if(!n&&!r)return[];let i=I(e,t.href).map(e=>R(e,`rottentomatoes`,n?`/tv/`:`/m/`));if(i.length)return i.map(e=>n?{...e,medium:`tv`,screenKind:`tv`}:e);let a=z(e,t,`rottentomatoes`,n?`/tv/`:`/m/`,n?`tv`:void 0);return a?[a]:[]}},{id:`wikipedia_screen`,hostPatterns:[`wikipedia.org`],detect(e,t){if(!/\/wiki\//i.test(t.pathname)||/\/wiki\/(File|Category|Help|Wikipedia|Template|Special|Talk|User):/i.test(t.pathname))return[];let n=I(e,t.href).map(e=>R(e,`wikipedia`,`/wiki/`));if(n.length)return n;let r=e.title||Ut(e),i=r.match(/^(.*?)\s*\((?:\d{4} )?(?:film|movie|documentary)/i),a=r.match(/^(.*?)\s*\((?:\d{4} )?(?:TV series|television series)/i);if(!i&&!a)return[];let o=`${r}\n${(e.querySelector(`.infobox`)?.textContent||``).replace(/([a-z])([A-Z])/g,`$1 $2`)}\n${(e.querySelector(`#mw-content-text p`)?.textContent||``).slice(0,600)}`,s=a?`tv`:`movie`;/documentary/i.test(o)&&(s=`documentary`);let c=Gt((a||i)[1]);return c?[{medium:s===`tv`?`tv`:`movie`,screenKind:s,title:c,year:Wt(r),imageUrl:L(e,`og:image`),sourcePageUrl:t.href,confidence:.87,evidence:[{type:`domain_adapter`,value:`wikipedia`,weight:.85},{type:`url_pattern`,value:`/wiki/`,weight:.7},{type:`page_title`,value:r.slice(0,80),weight:.75}],providerHint:`wikipedia`}]:[]}},{id:`netflix`,hostPatterns:[`netflix.com`],detect(e,t){let n=(L(e,`og:type`)||``).toLowerCase(),r=(e.body?.textContent||``).slice(0,2e3).toLowerCase(),i;if(n.includes(`tv`)||/tv series|seasons?|episodes?/.test(r)||/tv_show|tvseries/.test(n)?i=`tv`:/documentary|docuseries/.test(r)&&(i=`documentary`),!/\/(title|watch)\//i.test(t.pathname)&&!n.includes(`video`))return I(e,t.href).map(e=>R(e,`netflix`,t.pathname));let a=I(e,t.href).map(e=>R(e,`netflix`,`/title/`));if(a.length)return a;let o=z(e,t,`netflix`,t.pathname,i);return o?[o]:[]}},{id:`primevideo`,hostPatterns:[`amazon.`,`primevideo.com`],detect(e,t){let n=t.pathname;if(!(/\/(gp\/video|video\/detail|detail)\//i.test(n)||Ht(t.hostname,[`primevideo.com`])))return[];let r=I(e,t.href).map(e=>R(e,`primevideo`,n));if(r.length)return r;let i=(L(e,`og:type`)||``).toLowerCase(),a;i.includes(`tv`)&&(a=`tv`);let o=z(e,t,`primevideo`,n,a);return o?[o]:[]}}];function qt(e,t){let n=t.hostname,r=[];for(let i of Kt)if(Ht(n,i.hostPatterns))try{r.push(...i.detect(e,t))}catch{}return r}function Jt(e){return e.toLowerCase().replace(/[^a-z0-9\s]/g,``).replace(/\s+/g,` `).trim()}function Yt(e,t){let n={documentary:3,tv:2,movie:1},r=n[e.screenKind]>=n[t.screenKind]?e.screenKind:t.screenKind,i=Math.min(.98,Math.max(e.confidence,t.confidence)+.02);return{medium:r===`tv`?`tv`:`movie`,screenKind:r,title:e.title.length>=t.title.length?e.title:t.title,year:e.year??t.year,imageUrl:e.imageUrl||t.imageUrl,sourcePageUrl:e.sourcePageUrl||t.sourcePageUrl,confidence:i,evidence:[...e.evidence,...t.evidence],providerHint:e.providerHint||t.providerHint}}function Xt(e){let t=new Map;for(let n of e){let e=Jt(n.title);if(!e)continue;let r=t.get(e);t.set(e,r?Yt(r,n):n)}return[...t.values()].sort((e,t)=>t.confidence-e.confidence)}function Zt(e,t){let n=t.href,r=[];return r.push(...I(e,n)),r.push(...qt(e,t)),Xt(r).filter(e=>e.confidence>=.65&&e.title)}var B,V,Qt,H,$t,en,tn,nn,rn,an,on,sn={},cn=[],ln=/acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i,un=Array.isArray;function U(e,t){for(var n in t)e[n]=t[n];return e}function dn(e){e&&e.parentNode&&e.parentNode.removeChild(e)}function W(e,t,n){var r,i,a,o={};for(a in t)a==`key`?r=t[a]:a==`ref`?i=t[a]:o[a]=t[a];if(arguments.length>2&&(o.children=arguments.length>3?B.call(arguments,2):n),typeof e==`function`&&e.defaultProps!=null)for(a in e.defaultProps)o[a]===void 0&&(o[a]=e.defaultProps[a]);return fn(e,o,r,i,null)}function fn(e,t,n,r,i){var a={type:e,props:t,key:n,ref:r,__k:null,__:null,__b:0,__e:null,__c:null,constructor:void 0,__v:i??++Qt,__i:-1,__u:0};return i==null&&V.vnode!=null&&V.vnode(a),a}function G(e){return e.children}function pn(e,t){this.props=e,this.context=t}function K(e,t){if(t==null)return e.__?K(e.__,e.__i+1):null;for(var n;t<e.__k.length;t++)if((n=e.__k[t])!=null&&n.__e!=null)return n.__e;return typeof e.type==`function`?K(e):null}function mn(e){if(e.__P&&e.__d){var t=e.__v,n=t.__e,r=[],i=[],a=U({},t);a.__v=t.__v+1,V.vnode&&V.vnode(a),Tn(e.__P,a,t,e.__n,e.__P.namespaceURI,32&t.__u?[n]:null,r,n??K(t),!!(32&t.__u),i),a.__v=t.__v,a.__.__k[a.__i]=a,Dn(r,a,i),t.__e=t.__=null,a.__e!=n&&hn(a)}}function hn(e){if((e=e.__)!=null&&e.__c!=null)return e.__e=e.__c.base=null,e.__k.some(function(t){if(t!=null&&t.__e!=null)return e.__e=e.__c.base=t.__e}),hn(e)}function gn(e){(!e.__d&&(e.__d=!0)&&H.push(e)&&!_n.__r++||$t!=V.debounceRendering)&&(($t=V.debounceRendering)||en)(_n)}function _n(){try{for(var e,t=1;H.length;)H.length>t&&H.sort(tn),e=H.shift(),t=H.length,mn(e)}finally{H.length=_n.__r=0}}function vn(e,t,n,r,i,a,o,s,c,l,u){var d,f,p,m,h,g,_,v=r&&r.__k||cn,y=t.length;for(c=yn(n,t,v,c,y),d=0;d<y;d++)(p=n.__k[d])!=null&&(f=p.__i!=-1&&v[p.__i]||sn,p.__i=d,g=Tn(e,p,f,i,a,o,s,c,l,u),m=p.__e,p.ref&&f.ref!=p.ref&&(f.ref&&An(f.ref,null,p),u.push(p.ref,p.__c||m,p)),h==null&&m!=null&&(h=m),(_=!!(4&p.__u))||f.__k===p.__k?c=bn(p,c,e,_):typeof p.type==`function`&&g!==void 0?c=g:m&&(c=m.nextSibling),p.__u&=-7);return n.__e=h,c}function yn(e,t,n,r,i){var a,o,s,c,l,u=n.length,d=u,f=0;for(e.__k=Array(i),a=0;a<i;a++)(o=t[a])!=null&&typeof o!=`boolean`&&typeof o!=`function`?(typeof o==`string`||typeof o==`number`||typeof o==`bigint`||o.constructor==String?o=e.__k[a]=fn(null,o,null,null,null):un(o)?o=e.__k[a]=fn(G,{children:o},null,null,null):o.constructor===void 0&&o.__b>0?o=e.__k[a]=fn(o.type,o.props,o.key,o.ref?o.ref:null,o.__v):e.__k[a]=o,c=a+f,o.__=e,o.__b=e.__b+1,s=null,(l=o.__i=xn(o,n,c,d))!=-1&&(d--,(s=n[l])&&(s.__u|=2)),s==null||s.__v==null?(l==-1&&(i>u?f--:i<u&&f++),typeof o.type!=`function`&&(o.__u|=4)):l!=c&&(l==c-1?f--:l==c+1?f++:(l>c?f--:f++,o.__u|=4))):e.__k[a]=null;if(d)for(a=0;a<u;a++)(s=n[a])!=null&&!(2&s.__u)&&(s.__e==r&&(r=K(s)),jn(s,s));return r}function bn(e,t,n,r){var i,a;if(typeof e.type==`function`){for(i=e.__k,a=0;i&&a<i.length;a++)i[a]&&(i[a].__=e,t=bn(i[a],t,n,r));return t}e.__e!=t&&(r&&(t&&e.type&&!t.parentNode&&(t=K(e)),n.insertBefore(e.__e,t||null)),t=e.__e);do t&&=t.nextSibling;while(t!=null&&t.nodeType==8);return t}function xn(e,t,n,r){var i,a,o,s=e.key,c=e.type,l=t[n],u=l!=null&&(2&l.__u)==0;if(l===null&&s==null||u&&s==l.key&&c==l.type)return n;if(r>+!!u){for(i=n-1,a=n+1;i>=0||a<t.length;)if((l=t[o=i>=0?i--:a++])!=null&&!(2&l.__u)&&s==l.key&&c==l.type)return o}return-1}function Sn(e,t,n){t[0]==`-`?e.setProperty(t,n??``):e[t]=n==null?``:typeof n!=`number`||ln.test(t)?n:n+`px`}function Cn(e,t,n,r,i){var a,o;n:if(t==`style`)if(typeof n==`string`)e.style.cssText=n;else{if(typeof r==`string`&&(e.style.cssText=r=``),r)for(t in r)n&&t in n||Sn(e.style,t,``);if(n)for(t in n)r&&n[t]==r[t]||Sn(e.style,t,n[t])}else if(t[0]==`o`&&t[1]==`n`)a=t!=(t=t.replace(nn,`$1`)),o=t.toLowerCase(),t=o in e||t==`onFocusOut`||t==`onFocusIn`?o.slice(2):t.slice(2),e.l||={},e.l[t+a]=n,n?r?n.u=r.u:(n.u=rn,e.addEventListener(t,a?on:an,a)):e.removeEventListener(t,a?on:an,a);else{if(i==`http://www.w3.org/2000/svg`)t=t.replace(/xlink(H|:h)/,`h`).replace(/sName$/,`s`);else if(t!=`width`&&t!=`height`&&t!=`href`&&t!=`list`&&t!=`form`&&t!=`tabIndex`&&t!=`download`&&t!=`rowSpan`&&t!=`colSpan`&&t!=`role`&&t!=`popover`&&t in e)try{e[t]=n??``;break n}catch{}typeof n==`function`||(n==null||!1===n&&t[4]!=`-`?e.removeAttribute(t):e.setAttribute(t,t==`popover`&&n==1?``:n))}}function wn(e){return function(t){if(this.l){var n=this.l[t.type+e];if(t.t==null)t.t=rn++;else if(t.t<n.u)return;return n(V.event?V.event(t):t)}}}function Tn(e,t,n,r,i,a,o,s,c,l){var u,d,f,p,m,h,g,_,v,y,b,x,ee,S,te,C=t.type;if(t.constructor!==void 0)return null;128&n.__u&&(c=!!(32&n.__u),a=[s=t.__e=n.__e]),(u=V.__b)&&u(t);n:if(typeof C==`function`)try{if(_=t.props,v=C.prototype&&C.prototype.render,y=(u=C.contextType)&&r[u.__c],b=u?y?y.props.value:u.__:r,n.__c?g=(d=t.__c=n.__c).__=d.__E:(v?t.__c=d=new C(_,b):(t.__c=d=new pn(_,b),d.constructor=C,d.render=Mn),y&&y.sub(d),d.state||={},d.__n=r,f=d.__d=!0,d.__h=[],d._sb=[]),v&&d.__s==null&&(d.__s=d.state),v&&C.getDerivedStateFromProps!=null&&(d.__s==d.state&&(d.__s=U({},d.__s)),U(d.__s,C.getDerivedStateFromProps(_,d.__s))),p=d.props,m=d.state,d.__v=t,f)v&&C.getDerivedStateFromProps==null&&d.componentWillMount!=null&&d.componentWillMount(),v&&d.componentDidMount!=null&&d.__h.push(d.componentDidMount);else{if(v&&C.getDerivedStateFromProps==null&&_!==p&&d.componentWillReceiveProps!=null&&d.componentWillReceiveProps(_,b),t.__v==n.__v||!d.__e&&d.shouldComponentUpdate!=null&&!1===d.shouldComponentUpdate(_,d.__s,b)){t.__v!=n.__v&&(d.props=_,d.state=d.__s,d.__d=!1),t.__e=n.__e,t.__k=n.__k,t.__k.some(function(e){e&&(e.__=t)}),cn.push.apply(d.__h,d._sb),d._sb=[],d.__h.length&&o.push(d);break n}d.componentWillUpdate!=null&&d.componentWillUpdate(_,d.__s,b),v&&d.componentDidUpdate!=null&&d.__h.push(function(){d.componentDidUpdate(p,m,h)})}if(d.context=b,d.props=_,d.__P=e,d.__e=!1,x=V.__r,ee=0,v)d.state=d.__s,d.__d=!1,x&&x(t),u=d.render(d.props,d.state,d.context),cn.push.apply(d.__h,d._sb),d._sb=[];else do d.__d=!1,x&&x(t),u=d.render(d.props,d.state,d.context),d.state=d.__s;while(d.__d&&++ee<25);d.state=d.__s,d.getChildContext!=null&&(r=U(U({},r),d.getChildContext())),v&&!f&&d.getSnapshotBeforeUpdate!=null&&(h=d.getSnapshotBeforeUpdate(p,m)),S=u!=null&&u.type===G&&u.key==null?On(u.props.children):u,s=vn(e,un(S)?S:[S],t,n,r,i,a,o,s,c,l),d.base=t.__e,t.__u&=-161,d.__h.length&&o.push(d),g&&(d.__E=d.__=null)}catch(e){if(t.__v=null,c||a!=null)if(e.then){for(t.__u|=c?160:128;s&&s.nodeType==8&&s.nextSibling;)s=s.nextSibling;a[a.indexOf(s)]=null,t.__e=s}else{for(te=a.length;te--;)dn(a[te]);En(t)}else t.__e=n.__e,t.__k=n.__k,e.then||En(t);V.__e(e,t,n)}else a==null&&t.__v==n.__v?(t.__k=n.__k,t.__e=n.__e):s=t.__e=kn(n.__e,t,n,r,i,a,o,c,l);return(u=V.diffed)&&u(t),128&t.__u?void 0:s}function En(e){e&&(e.__c&&(e.__c.__e=!0),e.__k&&e.__k.some(En))}function Dn(e,t,n){for(var r=0;r<n.length;r++)An(n[r],n[++r],n[++r]);V.__c&&V.__c(t,e),e.some(function(t){try{e=t.__h,t.__h=[],e.some(function(e){e.call(t)})}catch(e){V.__e(e,t.__v)}})}function On(e){return typeof e!=`object`||!e||e.__b>0?e:un(e)?e.map(On):U({},e)}function kn(e,t,n,r,i,a,o,s,c){var l,u,d,f,p,m,h,g=n.props||sn,_=t.props,v=t.type;if(v==`svg`?i=`http://www.w3.org/2000/svg`:v==`math`?i=`http://www.w3.org/1998/Math/MathML`:i||=`http://www.w3.org/1999/xhtml`,a!=null){for(l=0;l<a.length;l++)if((p=a[l])&&`setAttribute`in p==!!v&&(v?p.localName==v:p.nodeType==3)){e=p,a[l]=null;break}}if(e==null){if(v==null)return document.createTextNode(_);e=document.createElementNS(i,v,_.is&&_),s&&=(V.__m&&V.__m(t,a),!1),a=null}if(v==null)g===_||s&&e.data==_||(e.data=_);else{if(a&&=B.call(e.childNodes),!s&&a!=null)for(g={},l=0;l<e.attributes.length;l++)g[(p=e.attributes[l]).name]=p.value;for(l in g)p=g[l],l==`dangerouslySetInnerHTML`?d=p:l==`children`||l in _||l==`value`&&`defaultValue`in _||l==`checked`&&`defaultChecked`in _||Cn(e,l,null,p,i);for(l in _)p=_[l],l==`children`?f=p:l==`dangerouslySetInnerHTML`?u=p:l==`value`?m=p:l==`checked`?h=p:s&&typeof p!=`function`||g[l]===p||Cn(e,l,p,g[l],i);if(u)s||d&&(u.__html==d.__html||u.__html==e.innerHTML)||(e.innerHTML=u.__html),t.__k=[];else if(d&&(e.innerHTML=``),vn(t.type==`template`?e.content:e,un(f)?f:[f],t,n,r,v==`foreignObject`?`http://www.w3.org/1999/xhtml`:i,a,o,a?a[0]:n.__k&&K(n,0),s,c),a!=null)for(l=a.length;l--;)dn(a[l]);s||(l=`value`,v==`progress`&&m==null?e.removeAttribute(`value`):m!=null&&(m!==e[l]||v==`progress`&&!m||v==`option`&&m!=g[l])&&Cn(e,l,m,g[l],i),l=`checked`,h!=null&&h!=e[l]&&Cn(e,l,h,g[l],i))}return e}function An(e,t,n){try{if(typeof e==`function`){var r=typeof e.__u==`function`;r&&e.__u(),r&&t==null||(e.__u=e(t))}else e.current=t}catch(e){V.__e(e,n)}}function jn(e,t,n){var r,i;if(V.unmount&&V.unmount(e),(r=e.ref)&&(r.current&&r.current!=e.__e||An(r,null,t)),(r=e.__c)!=null){if(r.componentWillUnmount)try{r.componentWillUnmount()}catch(e){V.__e(e,t)}r.base=r.__P=null}if(r=e.__k)for(i=0;i<r.length;i++)r[i]&&jn(r[i],t,n||typeof e.type!=`function`);n||dn(e.__e),e.__c=e.__=e.__e=void 0}function Mn(e,t,n){return this.constructor(e,n)}function q(e,t,n){var r,i,a,o;t==document&&(t=document.documentElement),V.__&&V.__(e,t),i=(r=typeof n==`function`)?null:n&&n.__k||t.__k,a=[],o=[],Tn(t,e=(!r&&n||t).__k=W(G,null,[e]),i||sn,sn,t.namespaceURI,!r&&n?[n]:i?null:t.firstChild?B.call(t.childNodes):null,a,!r&&n?n:i?i.__e:t.firstChild,r,o),Dn(a,e,o)}B=cn.slice,V={__e:function(e,t,n,r){for(var i,a,o;t=t.__;)if((i=t.__c)&&!i.__)try{if((a=i.constructor)&&a.getDerivedStateFromError!=null&&(i.setState(a.getDerivedStateFromError(e)),o=i.__d),i.componentDidCatch!=null&&(i.componentDidCatch(e,r||{}),o=i.__d),o)return i.__E=i}catch(t){e=t}throw e}},Qt=0,pn.prototype.setState=function(e,t){var n=this.__s!=null&&this.__s!=this.state?this.__s:this.__s=U({},this.state);typeof e==`function`&&(e=e(U({},n),this.props)),e&&U(n,e),e!=null&&this.__v&&(t&&this._sb.push(t),gn(this))},pn.prototype.forceUpdate=function(e){this.__v&&(this.__e=!0,e&&this.__h.push(e),gn(this))},pn.prototype.render=G,H=[],en=typeof Promise==`function`?Promise.prototype.then.bind(Promise.resolve()):setTimeout,tn=function(e,t){return e.__v.__b-t.__v.__b},_n.__r=0,nn=/(PointerCapture)$|Capture$/i,rn=0,an=wn(!1),on=wn(!0);var Nn=[{id:`8`,name:`Netflix`},{id:`9`,name:`Prime Video`},{id:`337`,name:`Disney+`},{id:`350`,name:`Apple TV+`},{id:`15`,name:`Hulu`},{id:`384`,name:`Max`}],Pn={"Amazon Prime Video":`Prime Video`,"Amazon Video":`Prime Video`,"HBO Max":`Max`,"Max Amazon Channel":`Max`};function Fn(e){if(Pn[e])return Pn[e];let t=Nn.find(t=>t.name===e);return t?t.name:Nn.find(t=>e.toLowerCase().includes(t.name.toLowerCase())||t.name.toLowerCase().includes(e.toLowerCase()))?.name??e}var In=`
:host {
  /* Ferrari / Cinema Black */
  --bg-base: #181818;
  --bg-elevated: #242424;
  --bg-overlay: #303030;
  --bg-hover: #3a3a3a;
  --bg-sunken: #121212;
  --fg-base: #ffffff;
  --fg-muted: #969696;
  --fg-subtle: #666666;
  --primary: #da291c;
  --primary-soft: rgba(218, 41, 28, 0.10);
  --primary-hover: #9d2211;
  --primary-pressed: #b01e0a;
  --border: hsla(0, 0%, 100%, 0.08);
  --border-subtle: hsla(0, 0%, 100%, 0.05);
  --gold: var(--primary);
  --accent-gold: var(--primary);

  /* Sanctuary */
  --bg-sanctuary: #181818;
  --bg-plaque: hsla(0, 0%, 12%, 0.92);
  --bg-plaque-hover: hsla(0, 0%, 16%, 0.96);
  --border-restraint: hsla(0, 0%, 100%, 0.08);
  --border-hero: rgba(218, 41, 28, 0.45);
  --accent-sanctuary: var(--border-hero);

  /* Text hierarchy */
  --text-reflection: #ffffff;
  --text-artwork: #d2d2d2;
  --text-title: #969696;
  --text-meta: #8f8f8f;
  --text-control: #666666;
  --text-sanctuary: var(--text-reflection);

  /* Typography — local fonts only: content scripts never request font files (no web-accessible
     resources, no third-party origins). Courier Prime / IBM Plex Mono are used if installed. */
  --font-editorial: 'Courier Prime', 'Courier New', ui-monospace, 'SF Mono', Menlo, Consolas, monospace;
  --font-display: var(--font-editorial);
  --font-ui: 'IBM Plex Mono', ui-monospace, 'SF Mono', Menlo, Consolas, 'Cascadia Code', 'Courier New', monospace;
  --font-sans: var(--font-ui);
  --font-mono: var(--font-ui);

  /* Spacing */
  --spacing-xs: 4px;
  --spacing-sm: 8px;
  --spacing-md: 12px;
  --spacing-lg: 20px;
  --spacing-xl: 24px;
  --spacing-2xl: 32px;
  --spacing-3xl: 48px;
  --spacing-4xl: 64px;
  --spacing-5xl: 96px;
  --spacing-super: 128px;

  /* Radius & motion (parity with tokens.css) */
  --radius-none: 0px;
  --radius-sm: 2px;
  --radius-md: 4px;
  --radius-lg: 8px;
  --duration-instant: 100ms;
  --duration-fast: 130ms;
  --duration-normal: 220ms;
  --duration-slow: 260ms;
  --duration-curtain: 280ms;
  --duration-curtain-close: 220ms;
  --ease-out: cubic-bezier(0.16, 1, 0.3, 1);
  --ease-focus-pull: cubic-bezier(0.25, 1, 0.5, 1);
  --transition-fast: var(--duration-fast) var(--ease-out);
  --transition-base: var(--duration-normal) ease;
  --transition-normal: var(--transition-base);
  --blur-hero: blur(16px);

  /* Shadows */
  --shadow-sm: 0 1px 3px hsla(240, 18%, 4%, 0.5);
  --shadow-md: 0 4px 16px hsla(240, 18%, 4%, 0.45);
  --shadow-lg: 0 12px 40px hsla(240, 18%, 4%, 0.5);
  --shadow-hero: 0 20px 60px hsla(240, 18%, 4%, 0.7);

  /* Aliases */
  --color-surface: var(--bg-elevated);
  --color-surface-elevated: var(--bg-overlay);
  --color-text: var(--fg-base);
  --color-text-secondary: var(--fg-muted);
  --color-text-muted: var(--fg-subtle);
  --color-accent-light: var(--primary);
  --color-accent-border: rgba(218, 41, 28, 0.25);

  /* Shadcn-compatible (content overlays) */
  --background: #181818;
  --foreground: #ffffff;
  --card: #303030;
  --card-foreground: #ffffff;
  --muted-foreground: #969696;
  --destructive: #ef4444;
  --ring: #da291c;
}
`;function Ln(){let e=document.createElement(`style`);return e.setAttribute(`data-subsume`,`tokens`),e.textContent=In,e}function Rn(e){let t=document.createElement(`style`);return t.setAttribute(`data-subsume`,`component`),t.textContent=e,t}function J(e,t){e.appendChild(Ln()),e.appendChild(Rn(t))}function zn(e){switch(e){case`to-watch`:return`planned`;case`watching`:return`in_progress`;case`watched`:return`completed`;case`abandoned`:return`abandoned`;default:return e}}var Bn={planned:`Want to watch`,in_progress:`Watching`,completed:`Watched`,abandoned:`Stopped`},Vn={planned:`Want to read`,in_progress:`Reading`,completed:`Read`,abandoned:`Did not finish`};function Hn(e,t){return t===`book`?Vn[e]:Bn[e]}function Un(e,t){return Hn(zn(e),t===`book`?`book`:t)}var Wn={movie:`Film`,tv:`Series`,book:`Book`},Gn=`Add to archive`,Kn=`In archive`,qn=`Remove from archive`;function Jn(e){return e===`book`?Wn.book:e===`tv`?Wn.tv:Wn.movie}var Yn=`Could not update archive. Try again.`,Xn=new WeakMap,Zn=Symbol(`subsume.testTrusted`);function Qn(){try{return{}.env?.VITEST?!0:!!globalThis.process?.env?.VITEST}catch{return!1}}function Y(e){let t=e.attachShadow({mode:`closed`});return Xn.set(e,t),t}function X(e){return e?!!(e.isTrusted===!0||Qn()&&e[Zn]===!0):!1}var $n=0;Array.isArray;function Z(e,t,n,r,i,a){t||={};var o,s,c=t;if(`ref`in c)for(s in c={},t)s==`ref`?o=t[s]:c[s]=t[s];var l={type:e,props:c,key:n,ref:o,__k:null,__:null,__b:0,__e:null,__c:null,constructor:void 0,__v:--$n,__i:-1,__u:0,__source:i,__self:a};if(typeof e==`function`&&(o=e.defaultProps))for(s in o)c[s]===void 0&&(c[s]=o[s]);return V.vnode&&V.vnode(l),l}function er(e){let t=e.getBoundingClientRect(),n=t.bottom+12+window.scrollY,r=t.left+window.scrollX;return r+340>window.innerWidth&&(r=window.innerWidth-340-16),r<8&&(r=8),t.bottom+12+380>window.innerHeight&&(n=t.top-380-12+window.scrollY),{top:n,left:r}}function tr({mediaItem:e,loading:t,position:n,visible:r,exiting:i=!1,inLibrary:a,libraryItem:o,onAdd:s,onRemove:c,onMouseEnter:l,onMouseLeave:u}){if(!r&&!i)return null;let d=e?.ratings.find(e=>e.provider===`imdb`),f=e?.ratings.find(e=>e.provider===`rt`);return Z(`div`,{className:`subsume-hover-card ${r&&!i?`subsume-visible`:``} ${i?`subsume-exiting`:``}`,style:{top:`${n.top}px`,left:`${n.left}px`},onMouseEnter:l,onMouseLeave:u,children:t?Z(`div`,{className:`subsume-skeleton`,children:[Z(`div`,{className:`subsume-skeleton-header`,children:[Z(`div`,{className:`subsume-skeleton-poster`}),Z(`div`,{className:`subsume-skeleton-info`,children:[Z(`div`,{className:`subsume-skeleton-line subsume-skeleton-title`}),Z(`div`,{className:`subsume-skeleton-line subsume-skeleton-meta`})]})]}),Z(`div`,{className:`subsume-skeleton-line subsume-skeleton-ratings`}),Z(`div`,{className:`subsume-skeleton-line subsume-skeleton-overview`}),Z(`div`,{className:`subsume-skeleton-line subsume-skeleton-overview short`})]}):e?Z(G,{children:[Z(`div`,{className:`subsume-card-header`,children:[Z(`div`,{className:`subsume-poster`,children:e.posterUrl?Z(`img`,{src:e.posterUrl,alt:e.canonicalTitle}):Z(`div`,{className:`subsume-poster-placeholder`,children:Z(`svg`,{width:`32`,height:`32`,viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,"stroke-width":`1.5`,children:[Z(`rect`,{x:`2`,y:`3`,width:`20`,height:`18`,rx:`2`}),Z(`path`,{d:`M7 3v18M17 3v18M2 9h5M17 9h5M2 15h5M17 15h5`})]})})}),Z(`div`,{className:`subsume-card-info`,children:[Z(`h3`,{className:`subsume-title`,children:e.canonicalTitle}),Z(`div`,{className:`subsume-meta`,children:[Z(`span`,{className:`subsume-year`,children:e.year}),e.runtimeMinutes&&Z(`span`,{className:`subsume-runtime`,children:[e.runtimeMinutes,` min`]}),Z(`span`,{className:`subsume-type-badge`,children:Jn(e.type)})]})]})]}),Z(`div`,{className:`subsume-ratings`,children:[d&&Z(`div`,{className:`subsume-rating-chip subsume-imdb`,children:[Z(`span`,{className:`subsume-rating-icon`,"aria-hidden":`true`,children:Z(`svg`,{width:`12`,height:`12`,viewBox:`0 0 24 24`,focusable:`false`,children:Z(`path`,{d:`M12 3.5l2.2 4.6 5 .7-3.6 3.5.9 5-4.5-2.4-4.5 2.4.9-5L4.8 8.8l5-.7L12 3.5z`,fill:`none`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinejoin:`round`})})}),Z(`span`,{className:`subsume-rating-label`,children:`IMDb`}),Z(`span`,{className:`subsume-rating-value`,children:[d.score,`/10`]})]}),f&&Z(`div`,{className:`subsume-rating-chip subsume-rt`,children:[Z(`span`,{className:`subsume-rating-icon`,"aria-hidden":`true`,children:Z(`svg`,{width:`12`,height:`12`,viewBox:`0 0 24 24`,focusable:`false`,children:Z(`path`,{d:`M12 3.5l2.2 4.6 5 .7-3.6 3.5.9 5-4.5-2.4-4.5 2.4.9-5L4.8 8.8l5-.7L12 3.5z`,fill:`none`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinejoin:`round`})})}),Z(`span`,{className:`subsume-rating-label`,children:`RT`}),Z(`span`,{className:`subsume-rating-value`,children:[f.score,`%`]})]})]}),e.streamingAvailability&&e.streamingAvailability.length>0&&Z(`div`,{className:`subsume-platforms`,children:e.streamingAvailability.slice(0,3).map((e,t)=>Z(`span`,{className:`subsume-platform-tag`,children:Fn(e.platform)},`${e.platform}-${t}`))}),Z(`div`,{className:`subsume-genres`,children:e.genres.map(e=>Z(`span`,{className:`subsume-genre-tag`,children:e},e))}),e.overview&&Z(`p`,{className:`subsume-overview`,children:e.overview}),a&&o&&Z(`div`,{className:`subsume-library-status-bar`,children:[Z(`div`,{className:`subsume-library-status-left`,children:[Z(`span`,{className:`subsume-library-label`,children:`Status`}),Z(`span`,{className:`subsume-status-badge status-${o.status}`,children:Un(o.status,e.type)})]}),o.userRating!==void 0&&Z(`div`,{className:`subsume-library-status-right`,children:[Z(`span`,{className:`subsume-library-label`,children:`My Rating`}),Z(`span`,{className:`subsume-user-rating-badge`,children:[Z(`span`,{className:`subsume-star`,children:`★`}),` `,o.userRating,`/10`]})]})]}),Z(`div`,{className:`subsume-actions`,children:a?Z(`button`,{type:`button`,className:`subsume-btn subsume-btn-danger`,onClick:e=>{X(e)&&c()},children:[Z(`svg`,{width:`14`,height:`14`,viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,"stroke-width":`2`,children:[Z(`polyline`,{points:`3 6 5 6 21 6`}),Z(`path`,{d:`M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2`})]}),qn]}):Z(`button`,{type:`button`,className:`subsume-btn subsume-btn-primary`,onClick:t=>{X(t)&&s(e.type)},children:[Z(`svg`,{width:`14`,height:`14`,viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,"stroke-width":`2`,children:[Z(`line`,{x1:`12`,y1:`5`,x2:`12`,y2:`19`}),Z(`line`,{x1:`5`,y1:`12`,x2:`19`,y2:`12`})]}),Gn]})})]}):Z(`div`,{className:`subsume-error`,children:`Could not load details`})})}var nr=class t{container;shadowRoot;currentTarget=null;showTimeout=null;hideTimeout=null;prefetchDebounce=null;isCardHovered=!1;isExiting=!1;libraryItems=new Map;prefetchCache=new Map;abortController=new AbortController;static SHOW_DELAY_MS=150;static PREFETCH_DEBOUNCE_MS=50;syncListener=null;constructor(){this.container=document.createElement(`div`),this.container.id=`subsume-hover-root`,this.shadowRoot=Y(this.container),J(this.shadowRoot,rr);let e=document.createElement(`div`);e.id=`subsume-mount`,this.shadowRoot.appendChild(e),document.body.appendChild(this.container),this.setupSyncListener()}setupSyncListener(){typeof chrome>`u`||!chrome.runtime?.onMessage||(this.syncListener=(e,t)=>{if(t.id!==chrome.runtime.id||!e||typeof e!=`object`)return;let n=e;if(n.type===`LIBRARY_UPDATED`){let e=n.libraryItem,t=n.mediaId||e?.mediaId;if(!t)return;n.action===`add`&&e||n.action===`update`&&e?this.libraryItems.set(t,e):n.action===`remove`&&this.libraryItems.delete(t)}},chrome.runtime.onMessage.addListener(this.syncListener))}async fetchLibraryStatus(t){let n=this.libraryItems.get(t);if(n)return n;try{let n=await u(e.CHECK_LIBRARY_STATUS,{mediaId:t});if(!n.success||!n.data?.inLibrary)return null;let r={mediaId:t,status:n.data.status??`to-watch`,addedAt:Date.now(),updatedAt:Date.now(),userRating:n.data.userRating};return this.libraryItems.set(t,r),r}catch(e){return console.error(`[Subsume] Failed to check library status:`,e),null}}destroy(){this.syncListener&&typeof chrome<`u`&&chrome.runtime?.onMessage&&(chrome.runtime.onMessage.removeListener(this.syncListener),this.syncListener=null),this.cancelShow(),this.cancelHide(),this.currentTarget=null,this.isCardHovered=!1,this.libraryItems.clear();let e=this.shadowRoot.getElementById(`subsume-mount`);e&&q(null,e),this.abortController.abort(),this.container.remove()}attachToElement(e,t,n){e.addEventListener(`mouseenter`,()=>{this.schedulePrefetch(t,n),this.scheduleShow(e,t,n)},{signal:this.abortController.signal}),e.addEventListener(`mouseleave`,()=>{this.scheduleHide()},{signal:this.abortController.signal})}prefetchKey(e,t){return`${e}:${t??``}`}schedulePrefetch(e,n){this.prefetchDebounce&&clearTimeout(this.prefetchDebounce),this.prefetchDebounce=setTimeout(()=>{this.prefetchDebounce=null,this.startPrefetch(e,n)},t.PREFETCH_DEBOUNCE_MS)}startPrefetch(t,n){let r=this.prefetchKey(t,n),i=this.prefetchCache.get(r);if(i)return i;let a={promise:u(e.GET_TITLE_DETAILS,{title:t,yearGuess:n}).then(e=>({success:e.success,data:e.data}))};return this.prefetchCache.set(r,a),a}scheduleShow(e,n,r){this.cancelHide(),this.cancelShow(),this.showTimeout=setTimeout(()=>{this.currentTarget=e,this.isExiting=!1,this.showCard(e,n,r)},t.SHOW_DELAY_MS)}scheduleHide(){this.cancelShow(),this.hideTimeout=setTimeout(()=>{this.isCardHovered||this.hideCard()},200)}cancelShow(){this.showTimeout&&=(clearTimeout(this.showTimeout),null)}cancelHide(){this.hideTimeout&&=(clearTimeout(this.hideTimeout),null)}async showCard(e,t,n){let r=this.shadowRoot.getElementById(`subsume-mount`);if(!r)return;let i=er(e);q(Z(tr,{mediaItem:null,loading:!0,position:i,visible:!0,inLibrary:!1,libraryItem:null,onAdd:()=>{},onRemove:()=>{},onMouseEnter:()=>{this.isCardHovered=!0,this.cancelHide()},onMouseLeave:()=>{this.isCardHovered=!1,this.scheduleHide()}}),r);try{let a=await this.startPrefetch(t,n).promise;if(this.currentTarget!==e)return;let o=a.success?a.data??null:null,s=o?await this.fetchLibraryStatus(o.id):null;if(this.currentTarget!==e)return;q(Z(tr,{mediaItem:o,loading:!1,position:i,visible:!0,inLibrary:s!==null,libraryItem:s,onAdd:e=>this.handleAdd(o,e),onRemove:()=>this.handleRemove(o),onMouseEnter:()=>{this.isCardHovered=!0,this.cancelHide()},onMouseLeave:()=>{this.isCardHovered=!1,this.scheduleHide()}}),r)}catch(t){console.error(`[Subsume] Failed to fetch title details:`,t),q(Z(tr,{mediaItem:null,loading:!1,position:er(e),visible:!0,inLibrary:!1,libraryItem:null,onAdd:()=>{},onRemove:()=>{},onMouseEnter:()=>{this.isCardHovered=!0,this.cancelHide()},onMouseLeave:()=>{this.isCardHovered=!1,this.scheduleHide()}}),r)}}clearMount(){let e=this.shadowRoot.getElementById(`subsume-mount`);e&&q(null,e),this.currentTarget=null,this.isExiting=!1}hideCard(){let e=this.shadowRoot.getElementById(`subsume-mount`);if(!e||!this.currentTarget){this.clearMount();return}let t=e.querySelector(`.subsume-hover-card`);if(!t||this.isExiting){this.clearMount();return}if(typeof window<`u`&&window.matchMedia?.(`(prefers-reduced-motion: reduce)`)?.matches){this.clearMount();return}this.isExiting=!0,t.classList.remove(`subsume-visible`),t.classList.add(`subsume-exiting`);let n=!1,r=()=>{n||(n=!0,t.removeEventListener(`transitionend`,i),this.clearMount())},i=e=>{e.propertyName===`opacity`&&r()};t.addEventListener(`transitionend`,i),setTimeout(r,300)}async handleAdd(t,n){try{await u(e.ADD_TO_LIST,{mediaItem:{...t,type:n},type:n});let r=this.shadowRoot.getElementById(`subsume-mount`);r&&(q(Z(`div`,{className:`subsume-hover-card subsume-visible subsume-added`,children:Z(`div`,{className:`subsume-added-msg`,children:[Z(`svg`,{width:`24`,height:`24`,viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,"stroke-width":`2`,children:Z(`path`,{d:`M20 6L9 17l-5-5`})}),Z(`span`,{children:`Added to archive!`})]})}),r),setTimeout(()=>this.hideCard(),1200))}catch(e){console.error(`[Subsume] Failed to add to list:`,e),this.showArchiveError()}}async handleRemove(t){try{await u(e.REMOVE_FROM_LIBRARY,{mediaId:t.id});let n=this.shadowRoot.getElementById(`subsume-mount`);n&&(q(Z(`div`,{className:`subsume-hover-card subsume-visible subsume-added`,children:Z(`div`,{className:`subsume-added-msg`,children:[Z(`svg`,{width:`24`,height:`24`,viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,"stroke-width":`2`,children:Z(`path`,{d:`M20 6L9 17l-5-5`})}),Z(`span`,{children:`Removed from archive!`})]})}),n),setTimeout(()=>this.hideCard(),1200))}catch(e){console.error(`[Subsume] Failed to remove from archive:`,e),this.showArchiveError()}}showArchiveError(){let e=this.shadowRoot.getElementById(`subsume-mount`);e&&(q(Z(`div`,{className:`subsume-hover-card subsume-visible subsume-added`,children:Z(`div`,{className:`subsume-error-alert`,role:`alert`,children:Yn})}),e),setTimeout(()=>this.hideCard(),3e3))}},rr=`
  :host {
    all: initial;
  }

  .subsume-hover-card {
    position: absolute;
    z-index: 2147483647;
    width: 340px;
    padding: var(--spacing-md);
    background: linear-gradient(135deg, hsla(240, 18%, 5%, 0.98), hsla(240, 14%, 11%, 0.98));
    backdrop-filter: blur(20px);
    -webkit-backdrop-filter: blur(20px);
    border: 1px solid var(--color-accent-border);
    border-radius: var(--radius-lg);
    box-shadow: var(--shadow-lg), 0 0 0 1px var(--border-subtle) inset;
    font-family: var(--font-ui);
    color: var(--foreground);
    opacity: 0;
    transform: translateY(8px) scale(0.96);
    transition: opacity 0.25s cubic-bezier(0.16, 1, 0.3, 1), transform 0.25s cubic-bezier(0.16, 1, 0.3, 1);
    pointer-events: none;
  }

  .subsume-hover-card.subsume-visible {
    opacity: 1;
    transform: translateY(0) scale(1);
    pointer-events: auto;
  }

  .subsume-hover-card.subsume-exiting {
    opacity: 0;
    transform: translateY(8px) scale(0.96);
    pointer-events: none;
    transition-duration: 0.18s; /* exit ≤ enter (0.25s) */
  }

  /* Skeleton loading */
  .subsume-skeleton {
    display: flex;
    flex-direction: column;
    gap: var(--spacing-md);
  }

  .subsume-skeleton-header {
    display: flex;
    gap: var(--spacing-md);
  }

  .subsume-skeleton-poster {
    flex-shrink: 0;
    width: 72px;
    height: 108px;
    border-radius: var(--radius-sm);
    background: var(--border-subtle);
    animation: subsume-skeleton-pulse 1.5s ease-in-out infinite;
  }

  .subsume-skeleton-info {
    flex: 1;
    display: flex;
    flex-direction: column;
    gap: var(--spacing-sm);
    padding-top: var(--spacing-xs);
  }

  .subsume-skeleton-line {
    height: 12px;
    border-radius: var(--radius-sm);
    background: rgba(255, 255, 255, 0.06);
    animation: subsume-skeleton-pulse 1.5s ease-in-out infinite;
  }

  .subsume-skeleton-title {
    width: 85%;
    height: 16px;
  }

  .subsume-skeleton-meta {
    width: 55%;
  }

  .subsume-skeleton-ratings {
    width: 70%;
  }

  .subsume-skeleton-overview {
    width: 100%;
  }

  .subsume-skeleton-overview.short {
    width: 75%;
  }

  @keyframes subsume-skeleton-pulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.4; }
  }

  /* Header */
  .subsume-card-header {
    display: flex;
    gap: var(--spacing-md);
    margin-bottom: var(--spacing-md);
  }

  .subsume-poster {
    flex-shrink: 0;
    width: 72px;
    height: 108px;
    border-radius: 2px;
    overflow: hidden;
    background: var(--border-subtle);
    border: 1px solid var(--border);
  }

  .subsume-poster img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }

  .subsume-poster-placeholder {
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--text-control);
  }

  .subsume-card-info {
    flex: 1;
    min-width: 0;
  }

  .subsume-title {
    margin: 0 0 var(--spacing-xs);
    font-size: 16px;
    font-weight: 700;
    color: var(--text-reflection);
    line-height: 1.3;
    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
  }

  .subsume-meta {
    display: flex;
    flex-wrap: wrap;
    gap: var(--spacing-sm);
    font-size: 12px;
    color: var(--text-meta);
  }

  .subsume-type-badge {
    background: var(--primary-soft);
    color: var(--primary);
    padding: 1px var(--spacing-sm);
    border-radius: var(--radius-sm);
    font-weight: 600;
    font-size: 10px;
    text-transform: uppercase;
    letter-spacing: 0.05em;
  }

  /* Ratings */
  .subsume-ratings {
    display: flex;
    gap: var(--spacing-md);
    margin-bottom: var(--spacing-md);
  }

  .subsume-rating-chip {
    display: flex;
    align-items: center;
    gap: 5px;
    padding: var(--spacing-xs) var(--spacing-md);
    border-radius: var(--radius-md);
    font-size: 12px;
    font-weight: 600;
  }

  .subsume-imdb {
    background: rgba(245, 197, 24, 0.08);
    border: 1px solid rgba(245, 197, 24, 0.15);
  }

  .subsume-rt {
    background: rgba(250, 50, 10, 0.08);
    border: 1px solid rgba(250, 50, 10, 0.15);
  }

  .subsume-rating-icon {
    font-size: 13px;
  }

  .subsume-rating-label {
    color: var(--text-meta);
    font-weight: 500;
    font-size: 10px;
    text-transform: uppercase;
    letter-spacing: 0.05em;
  }

  .subsume-rating-value {
    color: var(--text-reflection);
    font-variant-numeric: tabular-nums;
  }

  /* Streaming platforms */
  .subsume-platforms {
    display: flex;
    flex-wrap: wrap;
    gap: 5px;
    margin-bottom: var(--spacing-md);
  }

  .subsume-platform-tag {
    padding: 3px var(--spacing-sm);
    background: var(--primary-soft);
    border: 1px solid var(--color-accent-border);
    border-radius: var(--radius-md);
    font-size: 10px;
    font-weight: 600;
    color: var(--primary);
  }

  /* Genres */
  .subsume-genres {
    display: flex;
    flex-wrap: wrap;
    gap: 5px;
    margin-bottom: var(--spacing-md);
  }

  .subsume-genre-tag {
    padding: 3px var(--spacing-md);
    background: var(--border-subtle);
    border: 1px solid var(--border);
    border-radius: var(--radius-lg);
    font-size: 11px;
    color: var(--text-artwork);
    font-weight: 500;
  }

  /* Overview */
  .subsume-overview {
    margin: 0 0 var(--spacing-md);
    font-size: 12px;
    line-height: 1.5;
    color: var(--text-meta);
    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
  }

  /* Library Status Bar */
  .subsume-library-status-bar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: var(--spacing-md);
    background: var(--primary-soft);
    border: 1px solid var(--color-accent-border);
    border-radius: var(--radius-lg);
    margin-bottom: var(--spacing-md);
  }

  .subsume-library-status-left,
  .subsume-library-status-right {
    display: flex;
    flex-direction: column;
    gap: 3px;
  }

  .subsume-library-label {
    font-size: 9px;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    color: var(--text-meta);
    font-weight: 600;
  }

  .subsume-status-badge {
    font-size: 12px;
    font-weight: 600;
  }

  .subsume-status-badge.status-to-watch {
    color: var(--muted-foreground);
  }

  .subsume-status-badge.status-watching {
    color: var(--primary);
  }

  .subsume-status-badge.status-watched {
    color: var(--success-fg, var(--success));
  }

  .subsume-status-badge.status-abandoned {
    color: var(--danger-fg-strong, var(--destructive));
  }

  .subsume-user-rating-badge {
    font-size: 12px;
    font-weight: 700;
    color: var(--primary);
    display: flex;
    align-items: center;
    gap: 3px;
  }

  .subsume-star {
    color: var(--primary);
  }

  /* Actions */
  .subsume-actions {
    display: flex;
    gap: var(--spacing-sm);
  }

  .subsume-btn {
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: var(--spacing-sm);
    min-height: 44px;
    padding: var(--spacing-sm) var(--spacing-md);
    border: none;
    border-radius: var(--radius-md);
    font-size: 12px;
    font-weight: 600;
    font-family: inherit;
    cursor: pointer;
    box-sizing: border-box;
    transition: background 0.2s cubic-bezier(0.16, 1, 0.3, 1),
      border-color 0.2s cubic-bezier(0.16, 1, 0.3, 1),
      color 0.2s cubic-bezier(0.16, 1, 0.3, 1),
      box-shadow 0.2s cubic-bezier(0.16, 1, 0.3, 1),
      transform 0.2s cubic-bezier(0.16, 1, 0.3, 1);
  }

  .subsume-btn:active {
    transform: scale(0.97);
  }

  .subsume-btn:focus-visible {
    outline: 2px solid var(--accent-gold, var(--primary));
    outline-offset: 2px;
  }

  .subsume-btn-primary {
    background: linear-gradient(135deg, var(--ring), var(--primary-hover));
    color: var(--on-primary-fg, #ffffff);
    box-shadow: var(--shadow-sm);
  }

  .subsume-btn-primary:hover {
    background: linear-gradient(135deg, var(--primary-hover), var(--primary));
    transform: translateY(-1px);
    box-shadow: var(--shadow-md);
  }

  .subsume-btn-secondary {
    background: var(--border-subtle);
    color: var(--text-artwork);
    border: 1px solid var(--border);
  }

  .subsume-btn-secondary:hover {
    background: var(--border);
    border-color: var(--color-accent-border);
    color: var(--text-reflection);
    transform: translateY(-1px);
  }

  .subsume-btn-danger {
    flex: 1;
    background: var(--danger-bg);
    color: var(--danger-fg-strong, var(--destructive));
    border: 1px solid var(--danger-border);
  }

  .subsume-btn-danger:hover {
    background: var(--danger-bg);
    transform: translateY(-1px);
    border-color: var(--danger-border);
    filter: brightness(1.08);
  }

  /* Added confirmation */
  .subsume-added {
    display: flex;
    align-items: center;
    justify-content: center;
    min-height: 80px;
  }

  .subsume-added-msg {
    display: flex;
    align-items: center;
    gap: var(--spacing-md);
    color: var(--success-fg, var(--success));
    font-size: 15px;
    font-weight: 600;
  }

  /* Error */
  .subsume-error {
    text-align: center;
    padding: var(--spacing-xl);
    color: var(--text-control);
    font-size: 13px;
  }

  .subsume-error-alert {
    text-align: center;
    padding: var(--spacing-md) var(--spacing-lg);
    color: var(--danger-fg-strong, var(--destructive));
    font-size: 13px;
    font-weight: 600;
    line-height: 1.4;
  }

  @media (prefers-reduced-motion: reduce) {
    .subsume-hover-card {
      transition: none;
    }
    .subsume-skeleton-poster,
    .subsume-skeleton-line {
      animation: none;
    }
    .subsume-btn,
    .subsume-btn-primary,
    .subsume-btn-secondary {
      transition: none;
    }
    .subsume-btn:active,
    .subsume-btn-primary:hover,
    .subsume-btn-secondary:hover {
      transform: none;
    }
  }
`,ir=200,ar=Promise.resolve();function or(e){return e.length<=ir?e:`${e.slice(0,ir)}…`}function sr(e){if(typeof e==`string`)return or(l(e));if(e instanceof Error)return{name:e.name,message:or(l(e.message))};if(Array.isArray(e))return e.map(sr);if(e&&typeof e==`object`){let t={};for(let[n,r]of Object.entries(e))/(?:api[_-]?key|secret|token|password|email)/i.test(n)?t[n]=`[REDACTED]`:t[n]=sr(r);return t}return e}function cr(e,t){if(typeof chrome>`u`||!chrome.storage||!chrome.storage.local)return;let n=``;t.length>0&&(n=typeof t[0]==`string`?t[0]:JSON.stringify(t[0])),n=l(n);let r={timestamp:Date.now(),level:e,message:n,details:t.length>1?sr(t.slice(1)):void 0},i=r.details===void 0?void 0:typeof r.details==`string`?r.details:JSON.stringify(r.details);c(e,`logger`,n,i),ar=ar.then(async()=>{try{let e=(await new Promise((e,t)=>{try{let n=chrome.storage.local.get(`system_logs`,n=>{chrome.runtime?.lastError?t(Error(chrome.runtime.lastError.message)):e(n||{})});n&&typeof n.then==`function`&&n.then(e).catch(t)}catch(e){t(e)}})).system_logs||[];e.push(r),e.length>100&&(e=e.slice(e.length-100)),await new Promise((t,n)=>{try{let r=chrome.storage.local.set({system_logs:e},()=>{chrome.runtime?.lastError?n(Error(chrome.runtime.lastError.message)):t()});r&&typeof r.then==`function`&&r.then(t).catch(n)}catch(e){n(e)}})}catch(e){if(e instanceof Error&&(e.name===`QuotaExceededError`||e.message.includes(`QuotaExceededError`)))return}}).catch(()=>{})}var Q={log:(...e)=>{},info:(...e)=>{cr(`info`,e)},warn:(...e)=>{cr(`warn`,e)},error:(...e)=>{cr(`error`,e)},_flushQueue:()=>ar},lr=`data-subsume-badge`,ur=`subsume-poster-wrap`,dr=[`imdb`,`tmdb`,`rt`];function fr(e){if(!e||!Array.isArray(e))return null;for(let t of dr){let n=e.find(e=>e.provider===t);if(n&&typeof n.score==`number`&&n.score>0)return{provider:t,score:n.score>10?n.score/10:n.score}}return null}function pr({match:e,onReflect:t}){let n=fr(e.ratings),r=`8.4`;return n&&n.score>0&&(r=n.score.toFixed(1)),W(`div`,{className:`subsume-plaque-root`},W(`button`,{type:`button`,className:`museum-plaque`,onClick:e=>{X(e)&&(e.preventDefault(),e.stopPropagation(),t())},title:`Inscribe what stayed with you after this screening`,"aria-label":`Reflect on ${e.title}`},[W(`span`,{className:`plaque-score`},`★ ${r}`),W(`span`,{className:`plaque-reveal`},[W(`span`,{className:`plaque-separator`},`│`),W(`span`,{className:`plaque-action`},`Reflect`)])]))}var mr=`
  :host {
    all: initial;
    position: absolute;
    inset: 0;
    pointer-events: none;
    z-index: 2147483646;
    font-family: var(--font-ui);
  }

  .subsume-plaque-root {
    position: absolute;
    inset: 0;
    pointer-events: none;
  }

  .museum-plaque {
    position: absolute;
    bottom: var(--spacing-sm);
    right: var(--spacing-sm);
    display: inline-flex;
    align-items: center;
    gap: var(--spacing-sm);
    min-height: 44px;
    min-width: 44px;
    padding: var(--spacing-sm) var(--spacing-md);
    border-radius: var(--radius-md);
    background: var(--bg-plaque);
    color: var(--text-artwork);
    border: 1px solid var(--border-restraint);
    backdrop-filter: blur(8px);
    box-shadow: var(--shadow-md);
    font-family: var(--font-ui);
    font-size: 12px;
    font-weight: 500;
    line-height: 1;
    letter-spacing: 0.02em;
    cursor: pointer;
    pointer-events: auto;
    box-sizing: border-box;
    transition: background var(--duration-curtain) var(--ease-out),
      border-color var(--duration-curtain) var(--ease-out),
      box-shadow var(--duration-curtain) var(--ease-out),
      color var(--duration-curtain) var(--ease-out),
      transform var(--duration-curtain) var(--ease-out);
    overflow: hidden;
    white-space: nowrap;
  }

  .museum-plaque:hover {
    background: var(--bg-plaque-hover);
    color: var(--text-reflection);
    border-color: var(--border);
    box-shadow: var(--shadow-lg);
    transform: translateY(-1px);
  }

  .museum-plaque:focus-visible {
    outline: 2px solid var(--accent-gold, var(--primary));
    outline-offset: 2px;
  }

  .plaque-score {
    display: inline-block;
    color: var(--text-reflection);
    font-weight: 600;
  }

  .plaque-reveal {
    display: inline-flex;
    align-items: center;
    gap: var(--spacing-sm);
    /* Wave 4: opacity/transform only — avoid max-width thrash */
    max-width: 120px;
    opacity: 0;
    transform: translateX(-6px);
    pointer-events: none;
    transition:
      opacity var(--duration-fast, 130ms) var(--ease-out),
      transform var(--duration-fast, 130ms) var(--ease-out);
  }

  @media (hover: hover) and (pointer: fine) {
    .museum-plaque:hover .plaque-reveal {
      opacity: 1;
      transform: translateX(0);
      pointer-events: auto;
    }
  }

  .plaque-separator {
    opacity: 0.4;
  }

  .plaque-action {
    font-family: var(--font-editorial);
    font-size: 13px;
    font-weight: 600;
    color: var(--text-reflection);
  }

  @media (prefers-reduced-motion: reduce) {
    .museum-plaque, .plaque-reveal {
      transition: none;
    }
    .museum-plaque:hover {
      transform: none;
    }
  }
`,hr=class{badges=new Map;libraryIds=new Set;createdWrappers=new Set;syncListener=null;constructor(){this.setupSyncListener()}ensureWrapper(e){let t=e.parentElement;if(t?.classList.contains(ur))return t;let n=document.createElement(`span`);return n.className=ur,n.style.cssText=`position:relative;display:inline-block;line-height:0;vertical-align:top;`,e.parentNode?.insertBefore(n,e),n.appendChild(e),this.createdWrappers.add(n),n}setupSyncListener(){typeof chrome>`u`||!chrome.runtime?.onMessage||(this.syncListener=(e,t)=>{if(t.id!==chrome.runtime.id||!e||typeof e!=`object`||!(`type`in e)||e.type!==`LIBRARY_UPDATED`)return;let n=e,r=typeof n.mediaId==`string`?n.mediaId:typeof n.libraryItem?.mediaId==`string`?n.libraryItem.mediaId:void 0;if(r){n.action===`add`||n.action===`update`?this.libraryIds.add(r):n.action===`remove`&&this.libraryIds.delete(r);for(let e of this.badges.values())e.mediaId===r&&(e.inLibrary=n.action!==`remove`,this.renderBadge(e))}},chrome.runtime.onMessage.addListener(this.syncListener))}destroy(){this.syncListener&&typeof chrome<`u`&&chrome.runtime?.onMessage&&(chrome.runtime.onMessage.removeListener(this.syncListener),this.syncListener=null);for(let[e,t]of this.badges.entries()){q(null,t.mount),t.host.remove(),e.removeAttribute(lr);let n=e.parentElement;n&&this.createdWrappers.has(n)&&(n.parentNode?.insertBefore(e,n),n.remove(),this.createdWrappers.delete(n))}for(let e of this.createdWrappers)if(e.parentNode){for(;e.firstChild;)e.parentNode.insertBefore(e.firstChild,e);e.remove()}this.createdWrappers.clear(),this.badges.clear(),this.libraryIds.clear()}attachBadge(e,t){if(e.hasAttribute(lr))return;let n=`tmdb_${t.type}_${t.tmdbId}`,r=this.ensureWrapper(e),i=document.createElement(`div`);i.setAttribute(lr,`true`),i.style.cssText=`position:absolute;inset:0;pointer-events:none;`,r.appendChild(i);let a=Y(i);J(a,mr);let o=document.createElement(`div`);a.appendChild(o);let s={match:t,inLibrary:t.inLibrary||this.libraryIds.has(n),host:i,shadowRoot:a,mount:o,mediaId:n};e.setAttribute(lr,`true`),this.badges.set(e,s),this.renderBadge(s)}renderBadge(e){q(W(pr,{match:e.match,inLibrary:e.inLibrary,onReflect:()=>this.handleReflect(e)}),e.mount)}handleReflect(t){window.dispatchEvent(new CustomEvent(`OPEN_CAPTURE_CANVAS`,{detail:{mediaId:t.mediaId,match:t.match}})),u(e.OPEN_CAPTURE_CANVAS,{mediaId:t.mediaId,match:t.match}).catch(e=>{Q.warn(`[Subsume] OPEN_CAPTURE_CANVAS message dispatch:`,e)})}};function gr(e,t=120){let n=e.trim();if(n.length<=t)return n;let r=n.slice(0,t),i=r.lastIndexOf(` `);return`${i>t*.6?r.slice(0,i):r}…`}var $=`data-subsume-book-plaque`,_r=`subsume-book-plaque-stack`,vr=`
  :host {
    all: initial;
    pointer-events: none;
    z-index: 2147483645;
    font-family: var(--font-ui);
  }

  .book-plaque {
    display: inline-flex;
    align-items: center;
    gap: var(--spacing-sm);
    max-width: 240px;
    padding: 6px 10px;
    border-radius: var(--radius-md);
    background: var(--bg-plaque);
    color: var(--text-artwork);
    border: 1px solid rgba(218, 41, 28, 0.28);
    backdrop-filter: blur(8px);
    box-shadow: var(--shadow-md);
    font-family: var(--font-ui);
    font-size: 12px;
    font-weight: 500;
    line-height: 1.2;
    letter-spacing: 0.02em;
    pointer-events: auto;
    cursor: default;
    transition: background var(--duration-curtain) var(--ease-out),
      border-color var(--duration-curtain) var(--ease-out),
      box-shadow var(--duration-curtain) var(--ease-out),
      transform var(--duration-curtain) var(--ease-out);
    white-space: nowrap;
  }

  .book-plaque:hover {
    background: var(--bg-plaque-hover);
    border-color: rgba(218, 41, 28, 0.45);
    box-shadow: var(--shadow-lg);
    transform: translateY(-1px);
  }

  .plaque-star {
    color: var(--primary);
    font-weight: 600;
    flex-shrink: 0;
  }

  .plaque-dot {
    opacity: 0.45;
    flex-shrink: 0;
  }

  .plaque-action {
    position: relative;
    font-family: var(--font-editorial);
    font-size: 13px;
    font-weight: 600;
    color: var(--text-reflection);
    background: none;
    border: none;
    min-height: 44px;
    min-width: 44px;
    padding: 4px 8px;
    cursor: pointer;
    flex-shrink: 0;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    box-sizing: border-box;
    border-radius: var(--radius-sm);
  }

  /* Hit-slop expansion for dense plaque controls (Fitts) */
  .plaque-action::before {
    content: '';
    position: absolute;
    inset: -2px;
  }

  .plaque-action:hover {
    color: var(--primary-hover);
  }

  .plaque-action:focus-visible {
    color: var(--primary-hover);
    outline: 2px solid var(--accent-gold, var(--primary));
    outline-offset: 2px;
  }

  .plaque-archive-label {
    color: var(--primary);
    font-weight: 600;
    font-size: 11px;
    letter-spacing: 0.04em;
    text-transform: uppercase;
    flex-shrink: 0;
  }

  .plaque-title {
    overflow: hidden;
    text-overflow: ellipsis;
    color: var(--text-title);
    font-size: 11px;
    min-width: 0;
  }

  .plaque-add {
    position: relative;
    margin-left: 2px;
    min-height: 44px;
    min-width: 44px;
    padding: 4px 10px;
    border-radius: var(--radius-sm);
    border: 1px solid var(--border-restraint);
    background: transparent;
    color: var(--text-artwork);
    font-family: var(--font-ui);
    font-size: 10px;
    font-weight: 500;
    letter-spacing: 0.03em;
    cursor: pointer;
    flex-shrink: 0;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    box-sizing: border-box;
    transition: border-color 200ms ease, color 200ms ease, background 200ms ease;
  }

  .plaque-add::before {
    content: '';
    position: absolute;
    inset: -2px;
  }

  .plaque-add:hover {
    border-color: rgba(218, 41, 28, 0.5);
    color: var(--text-reflection);
    background: var(--primary-soft);
  }

  .plaque-add:focus-visible {
    border-color: rgba(218, 41, 28, 0.5);
    color: var(--text-reflection);
    background: var(--primary-soft);
    outline: 2px solid var(--accent-gold, var(--primary));
    outline-offset: 2px;
  }

  .plaque-add:disabled {
    opacity: 0.5;
    cursor: default;
  }

  .plaque-error {
    display: block;
    max-width: 220px;
    margin-top: 4px;
    padding: 4px 6px;
    border-radius: var(--radius-sm);
    background: var(--danger-bg, rgba(180, 40, 40, 0.2));
    color: var(--danger-fg-strong, #f5a8a8);
    border: 1px solid var(--danger-border, rgba(218, 41, 28, 0.4));
    font-family: var(--font-ui);
    font-size: 11px;
    font-weight: 600;
    line-height: 1.3;
    white-space: normal;
  }

  /* In-library open control — keyboard operable, Fitts min hit */
  .plaque-open {
    position: relative;
    display: inline-flex;
    align-items: center;
    gap: var(--spacing-sm);
    min-height: 44px;
    min-width: 44px;
    max-width: 100%;
    padding: 4px 6px;
    margin: 0;
    border: none;
    border-radius: var(--radius-sm);
    background: transparent;
    color: inherit;
    font: inherit;
    cursor: pointer;
    box-sizing: border-box;
  }

  .plaque-open:hover .plaque-archive-label,
  .plaque-open:hover .plaque-title {
    color: var(--primary-hover);
  }

  .plaque-open:focus-visible {
    outline: 2px solid var(--accent-gold, var(--primary));
    outline-offset: 2px;
  }

  @media (prefers-reduced-motion: reduce) {
    .book-plaque {
      transition: none;
    }
    .book-plaque:hover {
      transform: none;
    }
  }
`;function yr(e){return typeof HTMLElement<`u`&&e instanceof HTMLElement}function br(e,t=36){return gr(e,t)}var xr=class{plaques=[];stackHost=null;stackShadow=null;stackMount=null;stackCount=0;attachNear(e,t){if(!(!t.mediaId||!t.title)&&!this.plaques.some(e=>e.match.mediaId===t.mediaId)){if(yr(e)&&e!==document.documentElement&&e!==document.body){this.attachToElement(e,t);return}if(!yr(e)&&typeof e.top==`number`&&typeof e.left==`number`){this.attachAtRect(e,t);return}this.attachToStack(t)}}destroy(){for(let e of this.plaques)e.host.remove(),e.anchorEl?.hasAttribute($)&&e.anchorEl.removeAttribute($);this.plaques=[],this.stackHost?.remove(),this.stackHost=null,this.stackShadow=null,this.stackMount=null,this.stackCount=0}get size(){return this.plaques.length}attachToElement(e,t){let n=Sr(e),r=document.createElement(`div`);r.setAttribute($,t.mediaId),r.style.cssText=`position:absolute;bottom:8px;right:8px;z-index:2147483645;pointer-events:none;width:auto;height:auto;`,n.appendChild(r);let i=Y(r);J(i,vr);let a={match:{...t},host:r,shadowRoot:i,anchorEl:e,stacked:!1};this.plaques.push(a),this.renderPlaque(a)}attachAtRect(e,t){let n=document.createElement(`div`);n.setAttribute($,t.mediaId);let r=e.width??0,i=e.height??0;n.style.cssText=[`position:absolute`,`top:${Math.max(0,e.top+i-40)}px`,`left:${Math.max(0,e.left+Math.max(0,r-220))}px`,`z-index:2147483645`,`pointer-events:none`].join(`;`),document.documentElement.appendChild(n);let a=Y(n);J(a,vr);let o={match:{...t},host:n,shadowRoot:a,anchorEl:null,stacked:!1};this.plaques.push(o),this.renderPlaque(o)}ensureStack(){if(this.stackHost&&this.stackMount&&this.stackHost.isConnected)return{host:this.stackHost,mount:this.stackMount};let e=document.createElement(`div`);e.id=_r,e.setAttribute($,`stack`),e.style.cssText=[`position:fixed`,`top:16px`,`right:16px`,`z-index:2147483645`,`display:flex`,`flex-direction:column`,`align-items:flex-end`,`gap:8px`,`pointer-events:none`,`max-width:min(280px,calc(100vw - 32px))`].join(`;`),document.documentElement.appendChild(e);let t=Y(e);J(t,`${vr}
      .stack-root {
        display: flex;
        flex-direction: column;
        align-items: flex-end;
        gap: 8px;
        pointer-events: none;
      }
      .stack-root > * {
        pointer-events: auto;
      }
      `);let n=document.createElement(`div`);return n.className=`stack-root`,t.appendChild(n),this.stackHost=e,this.stackShadow=t,this.stackMount=n,{host:e,mount:n}}attachToStack(e){let{host:t,mount:n}=this.ensureStack(),r=document.createElement(`div`);r.setAttribute(`data-media-id`,e.mediaId),n.appendChild(r);let i=document.createElement(`div`);i.setAttribute($,e.mediaId),i.style.cssText=`pointer-events:auto;`,r.appendChild(i);let a=Y(i);J(a,vr);let o={match:{...e},host:i,shadowRoot:a,anchorEl:null,stacked:!0};this.stackCount+=1,this.plaques.push(o),this.renderPlaque(o)}renderPlaque(e){let{match:t}=e,n=document.createElement(`div`);if(n.className=`book-plaque`,n.setAttribute(`role`,`group`),n.setAttribute(`aria-label`,`Subsume: ${t.title}`),t.inLibrary){let r=document.createElement(`button`);r.type=`button`,r.className=`plaque-open`,r.setAttribute(`aria-label`,`Open ${t.title} in archive`),r.title=`Open ${t.title}`;let i=document.createElement(`span`);i.className=`plaque-archive-label`,i.textContent=Kn,r.appendChild(i);let a=document.createElement(`span`);a.className=`plaque-title`,a.textContent=br(t.title),a.title=t.title,r.appendChild(a),r.addEventListener(`click`,t=>{X(t)&&(t.preventDefault(),t.stopPropagation(),this.handleOpenDetail(e))}),n.appendChild(r)}else{let r=document.createElement(`span`);r.className=`plaque-star`,r.textContent=`★`,r.setAttribute(`aria-hidden`,`true`),n.appendChild(r);let i=document.createElement(`span`);i.className=`plaque-dot`,i.textContent=`·`,i.setAttribute(`aria-hidden`,`true`),n.appendChild(i);let a=document.createElement(`button`);a.type=`button`,a.className=`plaque-action`,a.textContent=`Reflect`,a.title=`Inscribe what stayed with you`,a.addEventListener(`click`,t=>{X(t)&&(t.preventDefault(),t.stopPropagation(),this.handleReflect(e))}),n.appendChild(a);let o=document.createElement(`span`);o.className=`plaque-title`,o.textContent=br(t.title),o.title=t.title,n.appendChild(o);let s=document.createElement(`button`);s.type=`button`,s.className=`plaque-add`,s.textContent=`Add`,s.title=Gn,s.addEventListener(`click`,t=>{X(t)&&(t.preventDefault(),t.stopPropagation(),this.handleAdd(e,s))}),n.appendChild(s)}e.shadowRoot.querySelector(`.book-plaque`)?.remove(),e.shadowRoot.appendChild(n)}handleReflect(t){let n=t.match.mediaId;window.dispatchEvent(new CustomEvent(`OPEN_CAPTURE_CANVAS`,{detail:{mediaId:n,match:t.match}})),u(e.OPEN_CAPTURE_CANVAS,{mediaId:n}).catch(e=>{Q.warn(`[Subsume] Book plaque OPEN_CAPTURE_CANVAS failed:`,e)})}handleOpenDetail(t){let n=t.match.mediaId;u(e.OPEN_DETAIL,{mediaId:n}).catch(e=>{Q.warn(`[Subsume] Book plaque OPEN_DETAIL failed:`,e)})}async handleAdd(t,n){n.disabled=!0;let{match:r}=t;t.shadowRoot.querySelector(`.plaque-error`)?.remove();try{r.media?await u(e.ADD_TO_ARCHIVE,{mediaItem:r.media,workId:r.mediaId,status:`to-watch`}):await u(e.ADD_TO_ARCHIVE,{workId:r.mediaId,status:`to-watch`}),t.match={...t.match,inLibrary:!0,status:`to-watch`},this.renderPlaque(t)}catch(e){n.disabled=!1,Q.warn(`[Subsume] Book plaque ADD_TO_ARCHIVE failed:`,e),this.showPlaqueError(t)}}showPlaqueError(e){let t=e.shadowRoot.querySelector(`.book-plaque`);if(!t)return;e.shadowRoot.querySelector(`.plaque-error`)?.remove();let n=document.createElement(`div`);n.className=`plaque-error`,n.setAttribute(`role`,`alert`),n.textContent=Yn,t.appendChild(n),window.setTimeout(()=>{n.remove()},3e3)}};function Sr(e){if(e instanceof HTMLImageElement){let t=e.parentElement;if(t?.classList.contains(`subsume-book-wrap`)||t?.classList.contains(`subsume-poster-wrap`))return t;let n=document.createElement(`span`);return n.className=`subsume-book-wrap`,n.style.cssText=`position:relative;display:inline-block;line-height:0;vertical-align:top;`,e.parentNode?.insertBefore(n,e),n.appendChild(e),n}let t=e.style,n=typeof window<`u`&&window.getComputedStyle?window.getComputedStyle(e).position:t.position;return(!n||n===`static`)&&(e.style.position=`relative`),e}function Cr(e){if(e.imageUrl)try{let t=new URL(e.imageUrl,document.baseURI).href,n=document.querySelectorAll(`img`);for(let r of n){let n=r.currentSrc||r.src;if(!n)continue;if(n===t||n.includes(e.imageUrl)||e.imageUrl.includes(n))return r;let i=e.imageUrl.split(`/`).pop()?.split(`?`)[0];if(i&&i.length>8&&n.includes(i))return r}}catch{}let t=(e.title||``).trim();if(t.length>=3){let e=t.slice(0,Math.min(40,t.length)).toLowerCase(),n=document.querySelectorAll(`img[alt]`);for(let t of n){let n=(t.getAttribute(`alt`)||``).toLowerCase();if(n.includes(e)||e.includes(n.slice(0,20)))return t}for(let t of[`h1`,`h2`,`[itemprop="name"]`,`.bookTitle`,`#bookTitle`]){let n=document.querySelectorAll(t);for(let t of n){let n=(t.textContent||``).replace(/\s+/g,` `).trim().toLowerCase();if(n.includes(e)||e.includes(n.slice(0,20)))return t}}let r=document.querySelector(`meta[property="og:image"]`)?.getAttribute(`content`);if(r){let e=document.querySelectorAll(`img`);for(let t of e){let e=t.currentSrc||t.src;if(e&&(e===r||e.includes(r)||r.includes(e)))return t}}}return null}var wr=`data-subsume-dock`,Tr=`subsume_page_reflections`,Er=200,Dr=180;function Or(e=window.location.hostname,t=window.location.pathname){return`${e}${t}`}async function kr(e){return((await chrome.storage.local.get(`subsume_page_reflections`)).subsume_page_reflections??{})[e]?.notes??``}async function Ar(e,t){let n={...(await chrome.storage.local.get(`subsume_page_reflections`)).subsume_page_reflections??{}},r=t.trim();r?n[e]={notes:r,updatedAt:Date.now()}:delete n[e],await chrome.storage.local.set({[Tr]:n})}var jr=`
  :host {
    all: initial;
    position: fixed;
    bottom: var(--spacing-xl);
    right: var(--spacing-xl);
    z-index: 2147483647;
  }

  .dock-container {
    font-family: var(--font-ui);
  }

  .dock-toggle-btn {
    background: var(--bg-overlay);
    color: var(--text-reflection);
    border: 1px solid var(--border-hero);
    min-height: 44px;
    padding: var(--spacing-md) var(--spacing-lg);
    border-radius: 20px;
    font-family: var(--font-editorial);
    font-size: 14px;
    font-weight: 500;
    cursor: pointer;
    box-shadow: var(--shadow-md);
    transition: border-color var(--duration-normal) var(--ease-out),
      box-shadow var(--duration-normal) var(--ease-out),
      transform var(--duration-normal) var(--ease-out);
    display: flex;
    align-items: center;
    gap: var(--spacing-sm);
    box-sizing: border-box;
  }

  .dock-toggle-btn:hover {
    border-color: var(--primary);
    transform: translateY(-1px);
    box-shadow: var(--shadow-lg);
  }

  .dock-toggle-btn:focus-visible {
    outline: 2px solid var(--accent-gold, var(--primary));
    outline-offset: 2px;
  }

  .dock-card {
    background: var(--bg-overlay);
    border: 1px solid var(--border-hero);
    border-radius: var(--radius-lg);
    width: 320px;
    padding: var(--spacing-md);
    box-shadow: var(--shadow-lg);
    display: flex;
    flex-direction: column;
    gap: var(--spacing-md);
  }

  /* Pill ↔ card enter/exit: transform + opacity only, ≤220ms */
  .dock-enter {
    opacity: 0;
    transform: translateY(8px);
  }

  .dock-enter-active {
    opacity: 1;
    transform: translateY(0);
    transition: opacity ${Er}ms ease-out, transform ${Er}ms ease-out;
  }

  .dock-exit {
    opacity: 0;
    transform: translateY(8px);
    transition: opacity ${Dr}ms ease-out, transform ${Dr}ms ease-out;
    pointer-events: none;
  }

  .dock-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  .dock-title {
    font-family: var(--font-editorial);
    font-size: 16px;
    font-weight: 600;
    color: var(--text-reflection);
  }

  .dock-collapse-btn {
    background: none;
    border: none;
    color: var(--text-meta);
    cursor: pointer;
    font-size: 14px;
    min-width: 44px;
    min-height: 44px;
    padding: var(--spacing-xs);
    display: inline-flex;
    align-items: center;
    justify-content: center;
    border-radius: var(--radius-sm);
    box-sizing: border-box;
  }

  .dock-collapse-btn:hover {
    color: var(--text-reflection);
  }

  .dock-collapse-btn:focus-visible {
    outline: 2px solid var(--accent-gold, var(--primary));
    outline-offset: 2px;
  }

  .dock-subtitle {
    font-size: 12px;
    color: var(--text-meta);
    line-height: 1.4;
  }

  .dock-textarea {
    width: 100%;
    height: 120px;
    background: var(--bg-sunken);
    border: 1px solid var(--color-accent-border);
    border-radius: var(--radius-md);
    padding: var(--spacing-md);
    color: var(--text-reflection);
    font-family: var(--font-editorial);
    font-size: 14px;
    resize: vertical;
    box-sizing: border-box;
  }

  .dock-textarea:focus {
    outline: none;
    border-color: var(--primary);
  }

  .dock-textarea:focus-visible {
    outline: 2px solid var(--ring, var(--primary));
    outline-offset: 2px;
  }

  .dock-footer {
    display: flex;
    justify-content: flex-end;
  }

  .dock-save-btn {
    background: var(--primary);
    color: var(--on-primary-fg, #ffffff);
    border: 1px solid var(--primary);
    min-height: 44px;
    padding: var(--spacing-sm) var(--spacing-md);
    border-radius: var(--radius-sm);
    font-size: 13px;
    font-weight: 500;
    cursor: pointer;
    transition: background-color var(--transition-fast), border-color var(--transition-fast), color var(--transition-fast);
    box-sizing: border-box;
  }

  .dock-save-btn:hover {
    background: var(--primary-soft);
    border-color: var(--primary);
  }

  .dock-save-btn:focus-visible {
    outline: 2px solid var(--accent-gold, var(--primary));
    outline-offset: 2px;
  }

  @media (prefers-reduced-motion: reduce) {
    .dock-toggle-btn,
    .dock-save-btn,
    .dock-enter,
    .dock-enter-active,
    .dock-exit {
      transition: none;
    }
    .dock-toggle-btn:hover {
      transform: none;
    }
    .dock-enter,
    .dock-enter-active,
    .dock-exit {
      opacity: 1;
      transform: none;
    }
  }
`,Mr=class{container=null;shadowRoot=null;mountPoint=null;isExpandedState=!1;pageKey=Or();boundOnToggle;boundOnSave;enterRaf=null;animTimeout=null;animGen=0;boundOnKeyDown=null;lastFocusBeforeExpand=null;constructor(){this.boundOnToggle=e=>{e.preventDefault(),e.stopPropagation(),X(e)&&this.toggle()},this.boundOnSave=e=>{e.preventDefault(),e.stopPropagation(),X(e)&&this.saveNotes()},this.boundOnKeyDown=e=>{e.key===`Escape`&&this.isExpandedState&&(e.preventDefault(),e.stopPropagation(),this.toggle())}}prefersReducedMotion(){try{return typeof window<`u`&&typeof window.matchMedia==`function`&&window.matchMedia(`(prefers-reduced-motion: reduce)`).matches}catch{return!1}}clearAnimTimers(){this.animGen+=1,this.enterRaf!=null&&(cancelAnimationFrame(this.enterRaf),this.enterRaf=null),this.animTimeout!=null&&(clearTimeout(this.animTimeout),this.animTimeout=null)}runEnterAnimation(e){if(this.prefersReducedMotion())return;let t=this.animGen;e.classList.remove(`dock-exit`,`dock-enter-active`),e.classList.add(`dock-enter`),this.enterRaf=requestAnimationFrame(()=>{this.enterRaf=requestAnimationFrame(()=>{this.enterRaf=null,!(t!==this.animGen||!e.isConnected)&&(e.classList.add(`dock-enter-active`),e.classList.remove(`dock-enter`),this.animTimeout=setTimeout(()=>{this.animTimeout=null,!(t!==this.animGen||!e.isConnected)&&e.classList.remove(`dock-enter-active`)},Er))})})}buildCard(){let e=document.createElement(`div`);e.className=`dock-card`;let t=document.createElement(`div`);t.className=`dock-header`;let n=document.createElement(`span`);n.className=`dock-title`,n.textContent=`Reflection dock`;let r=document.createElement(`button`);r.type=`button`,r.className=`dock-collapse-btn`,r.setAttribute(`aria-label`,`Collapse reflection dock`),r.textContent=`✕`,r.addEventListener(`click`,this.boundOnToggle),t.appendChild(n),t.appendChild(r);let i=document.createElement(`div`);i.className=`dock-subtitle`,i.textContent=`Notes for this page, saved to your archive`;let a=document.createElement(`textarea`);a.className=`dock-textarea`,a.placeholder=`What stayed with you after this page?`,a.setAttribute(`aria-label`,`Reflection notes for this page`),a.setAttribute(`name`,`subsume-page-reflection`),kr(this.pageKey).then(e=>{a.value=e,requestAnimationFrame(()=>{a.isConnected&&a.focus()})}).catch(e=>{Q.warn(`[Subsume] Failed to load page reflection notes:`,e)});let o=document.createElement(`div`);o.className=`dock-footer`;let s=document.createElement(`button`);return s.type=`button`,s.className=`dock-save-btn`,s.textContent=`Save reflection`,s.addEventListener(`click`,this.boundOnSave),o.appendChild(s),e.appendChild(t),e.appendChild(i),e.appendChild(a),e.appendChild(o),e}buildPill(){let e=document.createElement(`button`);return e.type=`button`,e.className=`dock-toggle-btn`,e.textContent=`✦ Reflection dock`,e.setAttribute(`aria-expanded`,`false`),e.setAttribute(`aria-label`,`Open reflection dock`),e.addEventListener(`click`,this.boundOnToggle),e}get isExpanded(){return this.isExpandedState}get shadow(){return this.shadowRoot}get host(){return this.container}mount(){this.container||(this.pageKey=Or(),this.container=document.createElement(`div`),this.container.setAttribute(wr,`true`),this.container.style.cssText=`position:fixed;bottom:24px;right:24px;z-index:2147483647;`,document.body.appendChild(this.container),this.shadowRoot=this.container.attachShadow({mode:`open`}),J(this.shadowRoot,jr),this.mountPoint=document.createElement(`div`),this.mountPoint.className=`dock-container`,this.shadowRoot.appendChild(this.mountPoint),this.boundOnKeyDown&&document.addEventListener(`keydown`,this.boundOnKeyDown,!0),this.render({animate:!1}),Q.log(`[Subsume] Mounted Auteur Screenplay Dock.`))}destroy(){this.clearAnimTimers(),this.boundOnKeyDown&&document.removeEventListener(`keydown`,this.boundOnKeyDown,!0),this.mountPoint&&=(this.mountPoint.innerHTML=``,null),this.container&&=(this.container.remove(),null),this.shadowRoot=null,this.isExpandedState=!1,this.boundOnToggle=null,this.boundOnSave=null,this.boundOnKeyDown=null,Q.log(`[Subsume] Destroyed Auteur Screenplay Dock.`)}toggle(){if(this.isExpandedState||(this.lastFocusBeforeExpand=document.activeElement),this.isExpandedState=!this.isExpandedState,this.render({animate:!0}),!this.isExpandedState&&this.lastFocusBeforeExpand?.isConnected)try{this.lastFocusBeforeExpand.focus()}catch{}}render(e={animate:!1}){if(!this.mountPoint)return;let t=this.prefersReducedMotion(),n=e.animate&&!t;if(this.isExpandedState){this.clearAnimTimers(),this.mountPoint.innerHTML=``;let e=this.buildCard();this.mountPoint.appendChild(e),n&&this.runEnterAnimation(e);return}let r=this.mountPoint.firstElementChild,i=r?.classList.contains(`dock-card`)??!1;if(n&&i&&r){this.clearAnimTimers();let e=this.animGen;r.classList.remove(`dock-enter`,`dock-enter-active`),r.classList.add(`dock-exit`),this.animTimeout=setTimeout(()=>{if(this.animTimeout=null,e!==this.animGen||!this.mountPoint||this.isExpandedState)return;this.mountPoint.innerHTML=``;let t=this.buildPill();this.mountPoint.appendChild(t),this.runEnterAnimation(t)},Dr);return}this.clearAnimTimers(),this.mountPoint.innerHTML=``,this.mountPoint.appendChild(this.buildPill())}saveNotes(){if(!this.shadowRoot)return;let e=this.shadowRoot.querySelector(`textarea`);if(!e)return;let t=e.value;Ar(this.pageKey,t).then(()=>{Q.log(`[Subsume] Successfully saved auteur reflection notes.`),this.isExpandedState&&this.toggle()}).catch(e=>{Q.error(`[Subsume] Error saving page reflection notes:`,e)})}},Nr=8,Pr=5,Fr=null,Ir=null,Lr=null,Rr=null;function zr(){Ne(),Fr?.destroy(),Fr=null,Ir?.destroy(),Ir=null,Lr?.destroy(),Lr=null,Rr?.destroy(),Rr=null}async function Br(t,n){let r=t.filter(e=>e.confidence>=Ct).slice(0,Nr).slice(0,Pr);for(let t of r)try{let r=await u(e.RESOLVE_PAGE_CANDIDATE,t);if(!r.success||!r.data||!r.data.resolved||!r.data.media)continue;let{media:i,inLibrary:a,libraryStatus:o}=r.data,s=Cr(t)??document.documentElement;n.attachNear(s,{mediaId:i.id,title:i.canonicalTitle||t.title||`Untitled`,authors:i.authors??t.authorOrCreator,year:i.year??t.year,inLibrary:!!a,status:o,media:i})}catch(e){Q.warn(`[Subsume] Book candidate resolve skipped:`,e)}}async function Vr(){zr(),Q.log(`[Subsume] Content script loaded.`);let t=window.location.hostname,n=await u(e.GET_CONTENT_PREFS,{hostname:t}),r=n.success?n.data:null,i=r?.hoverCardsEnabled??!0,a=r?.posterOverlaysEnabled??!0,o=r?.coverOverlaysEnabled??!0,s=r?.screenplayDockEnabled??!1,c=r?.detectionSensitivity||`medium`;if(r?.domainDisabled){Q.log(`[Subsume] Domain ${t} is blacklisted. Exiting.`);return}let l=new URL(window.location.href);if(r?.detectBooks!==!1)try{let e=kt(document,l);Q.log(`[Subsume] Book detection found ${e.length} candidate(s).`),o&&(Lr=new xr,Br(e,Lr))}catch(e){Q.error(`[Subsume] Book detection failed:`,e)}if(r?.detectScreenWorks!==!1)try{let e=Zt(document,l);if(e.length>0){let t=e[0];Q.log(`[Subsume] Screen page detection: "${t.title}" (${t.screenKind}, conf=${t.confidence.toFixed(2)}, n=${e.length})`)}}catch(e){Q.error(`[Subsume] Screen page detection failed:`,e)}if(!i&&!a&&!s&&!o){Q.log(`[Subsume] Page scanning and dock disabled in preferences. Exiting.`);return}s&&(Rr=new Mr,Rr.mount());let d=C(document.body).filter(e=>e.confidence===`high`),f=d.length>0;if(a){Ir=new hr;let e=(e,t)=>{Ir?.attachBadge(e,t)};je(c,e,f),(async()=>{if(f){Q.log(`[Subsume] Catalog page detected (${d.length} region(s)); prioritizing poster scan.`);for(let t of d)await De(c,e,t.element,{catalogMode:!0})}await De(c,e,document.body,{catalogMode:f})})().catch(e=>{Q.error(`[Subsume] Initial poster scan failed:`,e)})}if(i){Fr=new nr;let e=e=>{for(let t of e)Fr.attachToElement(t.element,t.title,t.yearGuess)},t=me();t.length>0&&(Q.log(`[Subsume] Found ${t.length} title(s) on page.`),e(t)),Me(t=>{Q.log(`[Subsume] Found ${t.length} new title(s) via mutation.`),e(t)})}else a&&Me(()=>{})}document.readyState===`loading`?document.addEventListener(`DOMContentLoaded`,Vr):Vr(),window.addEventListener(`pagehide`,zr)})();